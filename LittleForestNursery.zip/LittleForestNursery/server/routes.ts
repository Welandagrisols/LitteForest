import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertSpeciesSchema, 
  insertInputSchema, 
  insertTaskSchema, 
  insertTaskInputSchema, 
  insertSaleSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Species API routes
  app.get("/api/species", async (req: Request, res: Response) => {
    try {
      const allSpecies = await storage.getAllSpecies();
      res.json(allSpecies);
    } catch (error) {
      res.status(500).json({ message: "Error fetching species data", error });
    }
  });
  
  app.get("/api/species/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const species = await storage.getSpecies(id);
      if (!species) {
        return res.status(404).json({ message: "Species not found" });
      }
      
      res.json(species);
    } catch (error) {
      res.status(500).json({ message: "Error fetching species", error });
    }
  });
  
  app.post("/api/species", async (req: Request, res: Response) => {
    try {
      // Convert establishmentDate string to Date object before validation
      const data = {
        ...req.body,
        establishmentDate: req.body.establishmentDate ? 
          new Date(req.body.establishmentDate) : undefined
      };
      
      // Validate the transformed data
      const validatedData = insertSpeciesSchema.parse(data);
      const newSpecies = await storage.createSpecies(validatedData);
      res.status(201).json(newSpecies);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Validation error:", error.errors);
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      console.error("Server error:", error);
      res.status(500).json({ message: "Error creating species", error });
    }
  });
  
  app.put("/api/species/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const validatedData = insertSpeciesSchema.partial().parse(req.body);
      const updatedSpecies = await storage.updateSpecies(id, validatedData);
      
      if (!updatedSpecies) {
        return res.status(404).json({ message: "Species not found" });
      }
      
      res.json(updatedSpecies);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating species", error });
    }
  });
  
  app.delete("/api/species/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteSpecies(id);
      if (!success) {
        return res.status(404).json({ message: "Species not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting species", error });
    }
  });
  
  // Inputs API routes
  app.get("/api/inputs", async (req: Request, res: Response) => {
    try {
      const allInputs = await storage.getAllInputs();
      res.json(allInputs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching inputs data", error });
    }
  });
  
  app.get("/api/inputs/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const input = await storage.getInput(id);
      if (!input) {
        return res.status(404).json({ message: "Input not found" });
      }
      
      res.json(input);
    } catch (error) {
      res.status(500).json({ message: "Error fetching input", error });
    }
  });
  
  app.post("/api/inputs", async (req: Request, res: Response) => {
    try {
      // Convert dateReceived string to Date object before validation
      const data = {
        ...req.body,
        dateReceived: req.body.dateReceived ? 
          new Date(req.body.dateReceived) : undefined
      };
      
      const validatedData = insertInputSchema.parse(data);
      
      // Calculate total cost if not provided
      if (!validatedData.totalCost) {
        validatedData.totalCost = Number(validatedData.quantity) * Number(validatedData.unitCost);
      }
      
      const newInput = await storage.createInput(validatedData);
      res.status(201).json(newInput);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Validation error:", error.errors);
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      console.error("Server error:", error);
      res.status(500).json({ message: "Error creating input", error });
    }
  });
  
  app.put("/api/inputs/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const validatedData = insertInputSchema.partial().parse(req.body);
      
      // Recalculate total cost if quantity or unit cost changed
      if ((validatedData.quantity !== undefined || validatedData.unitCost !== undefined) && 
          !validatedData.totalCost) {
        const currentInput = await storage.getInput(id);
        if (currentInput) {
          const quantity = validatedData.quantity ?? currentInput.quantity;
          const unitCost = validatedData.unitCost ?? currentInput.unitCost;
          validatedData.totalCost = Number(quantity) * Number(unitCost);
        }
      }
      
      const updatedInput = await storage.updateInput(id, validatedData);
      
      if (!updatedInput) {
        return res.status(404).json({ message: "Input not found" });
      }
      
      res.json(updatedInput);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating input", error });
    }
  });
  
  app.delete("/api/inputs/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteInput(id);
      if (!success) {
        return res.status(404).json({ message: "Input not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting input", error });
    }
  });
  
  // Tasks API routes
  app.get("/api/tasks", async (req: Request, res: Response) => {
    try {
      const allTasks = await storage.getAllTasks();
      res.json(allTasks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tasks data", error });
    }
  });
  
  app.get("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Get associated inputs
      const taskInputs = await storage.getTaskInputs(id);
      
      res.json({ task, taskInputs });
    } catch (error) {
      res.status(500).json({ message: "Error fetching task", error });
    }
  });
  
  app.post("/api/tasks", async (req: Request, res: Response) => {
    try {
      const { task, inputs } = req.body;
      
      // Convert date strings to Date objects before validation
      const processedTask = {
        ...task,
        date: task.date ? new Date(task.date) : undefined,
        dueDate: task.dueDate ? new Date(task.dueDate) : null
      };
      
      const validatedTask = insertTaskSchema.parse(processedTask);
      
      // Calculate labor cost if not provided
      if (!validatedTask.laborCost && validatedTask.laborHours) {
        const hourlyRate = 10; // Default hourly rate
        validatedTask.laborCost = Number(validatedTask.laborHours) * hourlyRate;
      }
      
      const newTask = await storage.createTask(validatedTask);
      
      // Process inputs for the task
      let inputsCost = 0;
      const taskInputList = [];
      
      if (Array.isArray(inputs)) {
        for (const input of inputs) {
          const validatedInput = insertTaskInputSchema.parse({
            ...input,
            taskId: newTask.id
          });
          
          inputsCost += Number(validatedInput.cost);
          const newTaskInput = await storage.createTaskInput(validatedInput);
          taskInputList.push(newTaskInput);
        }
      }
      
      // Update task with total inputs cost
      const totalCost = Number(newTask.laborCost) + inputsCost;
      const updatedTask = await storage.updateTask(newTask.id, { 
        inputsCost, 
        totalCost 
      });
      
      res.status(201).json({
        task: updatedTask || newTask,
        taskInputs: taskInputList
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Validation error:", error.errors);
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      console.error("Server error:", error);
      res.status(500).json({ message: "Error creating task", error });
    }
  });
  
  app.put("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const validatedData = insertTaskSchema.partial().parse(req.body);
      
      // Recalculate labor cost if labor hours changed
      if (validatedData.laborHours !== undefined && !validatedData.laborCost) {
        const hourlyRate = 10; // Default hourly rate
        validatedData.laborCost = Number(validatedData.laborHours) * hourlyRate;
      }
      
      const updatedTask = await storage.updateTask(id, validatedData);
      
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(updatedTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating task", error });
    }
  });
  
  app.delete("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteTask(id);
      if (!success) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting task", error });
    }
  });
  
  // Sales API routes
  app.get("/api/sales", async (req: Request, res: Response) => {
    try {
      const allSales = await storage.getAllSales();
      res.json(allSales);
    } catch (error) {
      res.status(500).json({ message: "Error fetching sales data", error });
    }
  });
  
  app.get("/api/sales/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const sale = await storage.getSale(id);
      if (!sale) {
        return res.status(404).json({ message: "Sale not found" });
      }
      
      res.json(sale);
    } catch (error) {
      res.status(500).json({ message: "Error fetching sale", error });
    }
  });
  
  app.post("/api/sales", async (req: Request, res: Response) => {
    try {
      // Convert date string to Date object before validation
      const data = {
        ...req.body,
        date: req.body.date ? new Date(req.body.date) : undefined
      };
      
      const validatedData = insertSaleSchema.parse(data);
      
      // Calculate total revenue if not provided
      if (!validatedData.totalRevenue) {
        validatedData.totalRevenue = Number(validatedData.quantity) * Number(validatedData.unitPrice);
      }
      
      const newSale = await storage.createSale(validatedData);
      res.status(201).json(newSale);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Validation error:", error.errors);
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      console.error("Server error:", error);
      res.status(500).json({ message: "Error creating sale", error });
    }
  });
  
  app.put("/api/sales/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const validatedData = insertSaleSchema.partial().parse(req.body);
      
      // Recalculate total revenue if quantity or unit price changed
      if ((validatedData.quantity !== undefined || validatedData.unitPrice !== undefined) && 
          !validatedData.totalRevenue) {
        const currentSale = await storage.getSale(id);
        if (currentSale) {
          const quantity = validatedData.quantity ?? currentSale.quantity;
          const unitPrice = validatedData.unitPrice ?? currentSale.unitPrice;
          validatedData.totalRevenue = Number(quantity) * Number(unitPrice);
        }
      }
      
      const updatedSale = await storage.updateSale(id, validatedData);
      
      if (!updatedSale) {
        return res.status(404).json({ message: "Sale not found" });
      }
      
      res.json(updatedSale);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating sale", error });
    }
  });
  
  app.delete("/api/sales/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteSale(id);
      if (!success) {
        return res.status(404).json({ message: "Sale not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Error deleting sale", error });
    }
  });
  
  // Dashboard/Reports API
  app.get("/api/reports/overview", async (req: Request, res: Response) => {
    try {
      const species = await storage.getAllSpecies();
      const tasks = await storage.getAllTasks();
      const sales = await storage.getAllSales();
      
      // Calculate totals
      const totalInventory = species.reduce((sum, s) => sum + s.quantity, 0);
      const openTasks = tasks.filter(t => t.status === "Pending").length;
      
      // Monthly sales
      const monthlySales = sales.reduce((sum, s) => sum + Number(s.totalRevenue), 0);
      
      // Calculate costs from tasks
      const totalCosts = tasks.reduce((sum, t) => sum + Number(t.totalCost), 0);
      
      // Net profit
      const netProfit = monthlySales - totalCosts;
      
      // Get product profitability
      const speciesMap = new Map();
      species.forEach(s => {
        speciesMap.set(s.id, { 
          name: s.localName,
          scientificName: s.scientificName,
          quantity: s.quantity
        });
      });
      
      // Count sales by species
      const salesBySpecies = sales.reduce((acc, sale) => {
        const speciesId = sale.speciesId;
        if (!acc[speciesId]) {
          acc[speciesId] = {
            quantity: 0,
            revenue: 0
          };
        }
        acc[speciesId].quantity += sale.quantity;
        acc[speciesId].revenue += Number(sale.totalRevenue);
        return acc;
      }, {} as Record<number, { quantity: number, revenue: number }>);
      
      // Calculate profitability
      const profitability = Object.entries(salesBySpecies).map(([speciesId, data]) => {
        const species = speciesMap.get(Number(speciesId));
        return {
          speciesId: Number(speciesId),
          name: species?.name || "Unknown",
          scientificName: species?.scientificName || "",
          quantitySold: data.quantity,
          revenue: data.revenue,
          profitPercentage: Math.round((data.revenue / monthlySales) * 100)
        };
      }).sort((a, b) => b.profitPercentage - a.profitPercentage);
      
      // Top selling product
      const topSellingProduct = profitability[0] || null;
      
      res.json({
        totalInventory,
        openTasks,
        monthlySales,
        netProfit,
        profitability,
        topSellingProduct
      });
    } catch (error) {
      res.status(500).json({ message: "Error generating reports", error });
    }
  });
  
  // Create the HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
