import {
  species, type Species, type InsertSpecies,
  inputs, type Input, type InsertInput,
  tasks, type Task, type InsertTask,
  taskInputs, type TaskInput, type InsertTaskInput,
  sales, type Sale, type InsertSale,
  users, type User, type InsertUser
} from "@shared/schema";

// Storage interface for CRUD operations
export interface IStorage {
  // Species operations
  getAllSpecies(): Promise<Species[]>;
  getSpecies(id: number): Promise<Species | undefined>;
  createSpecies(data: InsertSpecies): Promise<Species>;
  updateSpecies(id: number, data: Partial<InsertSpecies>): Promise<Species | undefined>;
  deleteSpecies(id: number): Promise<boolean>;
  
  // Inputs operations
  getAllInputs(): Promise<Input[]>;
  getInput(id: number): Promise<Input | undefined>;
  createInput(data: InsertInput): Promise<Input>;
  updateInput(id: number, data: Partial<InsertInput>): Promise<Input | undefined>;
  deleteInput(id: number): Promise<boolean>;
  
  // Tasks operations
  getAllTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(data: InsertTask): Promise<Task>;
  updateTask(id: number, data: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // TaskInputs operations
  getTaskInputs(taskId: number): Promise<TaskInput[]>;
  createTaskInput(data: InsertTaskInput): Promise<TaskInput>;
  deleteTaskInput(id: number): Promise<boolean>;
  
  // Sales operations
  getAllSales(): Promise<Sale[]>;
  getSale(id: number): Promise<Sale | undefined>;
  createSale(data: InsertSale): Promise<Sale>;
  updateSale(id: number, data: Partial<InsertSale>): Promise<Sale | undefined>;
  deleteSale(id: number): Promise<boolean>;
  
  // Users operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private species: Map<number, Species>;
  private inputs: Map<number, Input>;
  private tasks: Map<number, Task>;
  private taskInputs: Map<number, TaskInput>;
  private sales: Map<number, Sale>;
  private users: Map<number, User>;
  
  private speciesId: number;
  private inputId: number;
  private taskId: number;
  private taskInputId: number;
  private saleId: number;
  private userId: number;
  
  constructor() {
    this.species = new Map();
    this.inputs = new Map();
    this.tasks = new Map();
    this.taskInputs = new Map();
    this.sales = new Map();
    this.users = new Map();
    
    this.speciesId = 1;
    this.inputId = 1;
    this.taskId = 1;
    this.taskInputId = 1;
    this.saleId = 1;
    this.userId = 1;
    
    // Add sample user
    this.createUser({
      username: "admin",
      password: "password",
      fullName: "John Smith",
      role: "admin"
    });
    
    // Add sample data
    this.seedSampleData();
  }
  
  // Seed sample data for demo purposes
  private seedSampleData() {
    // Sample Species
    const oakSaplings = this.createSpecies({
      localName: "Oak Saplings",
      scientificName: "Quercus robur",
      quantity: 132,
      establishmentDate: new Date("2025-03-12"),
      notes: ""
    });
    
    const pineSeedlings = this.createSpecies({
      localName: "Pine Seedlings",
      scientificName: "Pinus sylvestris",
      quantity: 85,
      establishmentDate: new Date("2025-04-03"),
      notes: ""
    });
    
    const mapleTrees = this.createSpecies({
      localName: "Maple Trees",
      scientificName: "Acer saccharum",
      quantity: 43,
      establishmentDate: new Date("2025-02-28"),
      notes: ""
    });
    
    const appleTrees = this.createSpecies({
      localName: "Apple Trees",
      scientificName: "Malus domestica",
      quantity: 39,
      establishmentDate: new Date("2025-03-21"),
      notes: ""
    });
    
    // Sample Inputs
    this.createInput({
      name: "Forest Soil",
      category: "Soil",
      quantity: 500,
      unit: "kg",
      unitCost: 2.5,
      totalCost: 1250,
      dateReceived: new Date("2025-03-01"),
      notes: "Premium quality forest soil"
    });
    
    this.createInput({
      name: "Polytubes",
      category: "Container",
      quantity: 1000,
      unit: "pieces",
      unitCost: 0.5,
      totalCost: 500,
      dateReceived: new Date("2025-03-15"),
      notes: "Medium-sized polytubes"
    });
    
    // Sample Sales
    this.createSale({
      speciesId: oakSaplings.id,
      quantity: 354,
      unitPrice: 16.5,
      totalRevenue: 5841,
      buyer: "Green Gardens Ltd",
      date: new Date("2025-04-15"),
      notes: "Bulk order for landscaping project"
    });
  }
  
  // Species methods
  async getAllSpecies(): Promise<Species[]> {
    return Array.from(this.species.values());
  }
  
  async getSpecies(id: number): Promise<Species | undefined> {
    return this.species.get(id);
  }
  
  async createSpecies(data: InsertSpecies): Promise<Species> {
    const id = this.speciesId++;
    const species = { ...data, id };
    this.species.set(id, species);
    return species;
  }
  
  async updateSpecies(id: number, data: Partial<InsertSpecies>): Promise<Species | undefined> {
    const species = this.species.get(id);
    if (!species) return undefined;
    
    const updated = { ...species, ...data };
    this.species.set(id, updated);
    return updated;
  }
  
  async deleteSpecies(id: number): Promise<boolean> {
    return this.species.delete(id);
  }
  
  // Inputs methods
  async getAllInputs(): Promise<Input[]> {
    return Array.from(this.inputs.values());
  }
  
  async getInput(id: number): Promise<Input | undefined> {
    return this.inputs.get(id);
  }
  
  async createInput(data: InsertInput): Promise<Input> {
    const id = this.inputId++;
    const input = { ...data, id };
    this.inputs.set(id, input);
    return input;
  }
  
  async updateInput(id: number, data: Partial<InsertInput>): Promise<Input | undefined> {
    const input = this.inputs.get(id);
    if (!input) return undefined;
    
    const updated = { ...input, ...data };
    this.inputs.set(id, updated);
    return updated;
  }
  
  async deleteInput(id: number): Promise<boolean> {
    return this.inputs.delete(id);
  }
  
  // Tasks methods
  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async createTask(data: InsertTask): Promise<Task> {
    const id = this.taskId++;
    const task = { ...data, id };
    this.tasks.set(id, task);
    return task;
  }
  
  async updateTask(id: number, data: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updated = { ...task, ...data };
    this.tasks.set(id, updated);
    return updated;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }
  
  // TaskInputs methods
  async getTaskInputs(taskId: number): Promise<TaskInput[]> {
    return Array.from(this.taskInputs.values()).filter(ti => ti.taskId === taskId);
  }
  
  async createTaskInput(data: InsertTaskInput): Promise<TaskInput> {
    const id = this.taskInputId++;
    const taskInput = { ...data, id };
    this.taskInputs.set(id, taskInput);
    return taskInput;
  }
  
  async deleteTaskInput(id: number): Promise<boolean> {
    return this.taskInputs.delete(id);
  }
  
  // Sales methods
  async getAllSales(): Promise<Sale[]> {
    return Array.from(this.sales.values());
  }
  
  async getSale(id: number): Promise<Sale | undefined> {
    return this.sales.get(id);
  }
  
  async createSale(data: InsertSale): Promise<Sale> {
    const id = this.saleId++;
    const sale = { ...data, id };
    this.sales.set(id, sale);
    
    // Update species quantity
    const species = this.species.get(data.speciesId);
    if (species) {
      const updatedSpecies = { 
        ...species, 
        quantity: Math.max(0, species.quantity - data.quantity) 
      };
      this.species.set(species.id, updatedSpecies);
    }
    
    return sale;
  }
  
  async updateSale(id: number, data: Partial<InsertSale>): Promise<Sale | undefined> {
    const sale = this.sales.get(id);
    if (!sale) return undefined;
    
    // If quantity is being updated, adjust species inventory
    if (data.quantity !== undefined && data.quantity !== sale.quantity) {
      const species = this.species.get(sale.speciesId);
      if (species) {
        // Add back the old quantity, then remove the new quantity
        const updatedQuantity = species.quantity + sale.quantity - data.quantity;
        const updatedSpecies = { ...species, quantity: Math.max(0, updatedQuantity) };
        this.species.set(species.id, updatedSpecies);
      }
    }
    
    const updated = { ...sale, ...data };
    this.sales.set(id, updated);
    return updated;
  }
  
  async deleteSale(id: number): Promise<boolean> {
    const sale = this.sales.get(id);
    if (sale) {
      // Return the sold quantity back to inventory
      const species = this.species.get(sale.speciesId);
      if (species) {
        const updatedSpecies = { 
          ...species, 
          quantity: species.quantity + sale.quantity 
        };
        this.species.set(species.id, updatedSpecies);
      }
    }
    return this.sales.delete(id);
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }
}

import { db } from "./db";
import { eq, and } from 'drizzle-orm';
import * as schema from "@shared/schema";

export class DatabaseStorage implements IStorage {
  async getAllSpecies(): Promise<Species[]> {
    return await db.select().from(schema.species);
  }

  async getSpecies(id: number): Promise<Species | undefined> {
    const [species] = await db.select().from(schema.species).where(eq(schema.species.id, id));
    return species || undefined;
  }

  async createSpecies(data: InsertSpecies): Promise<Species> {
    const [species] = await db
      .insert(schema.species)
      .values(data)
      .returning();
    return species;
  }

  async updateSpecies(id: number, data: Partial<InsertSpecies>): Promise<Species | undefined> {
    const [species] = await db
      .update(schema.species)
      .set(data)
      .where(eq(schema.species.id, id))
      .returning();
    return species;
  }

  async deleteSpecies(id: number): Promise<boolean> {
    const deleted = await db
      .delete(schema.species)
      .where(eq(schema.species.id, id))
      .returning({ id: schema.species.id });
    return deleted.length > 0;
  }

  async getAllInputs(): Promise<Input[]> {
    return await db.select().from(schema.inputs);
  }

  async getInput(id: number): Promise<Input | undefined> {
    const [input] = await db.select().from(schema.inputs).where(eq(schema.inputs.id, id));
    return input || undefined;
  }

  async createInput(data: InsertInput): Promise<Input> {
    const [input] = await db
      .insert(schema.inputs)
      .values(data)
      .returning();
    return input;
  }

  async updateInput(id: number, data: Partial<InsertInput>): Promise<Input | undefined> {
    const [input] = await db
      .update(schema.inputs)
      .set(data)
      .where(eq(schema.inputs.id, id))
      .returning();
    return input;
  }

  async deleteInput(id: number): Promise<boolean> {
    const deleted = await db
      .delete(schema.inputs)
      .where(eq(schema.inputs.id, id))
      .returning({ id: schema.inputs.id });
    return deleted.length > 0;
  }

  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(schema.tasks);
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(schema.tasks).where(eq(schema.tasks.id, id));
    return task || undefined;
  }

  async createTask(data: InsertTask): Promise<Task> {
    const [task] = await db
      .insert(schema.tasks)
      .values(data)
      .returning();
    return task;
  }

  async updateTask(id: number, data: Partial<InsertTask>): Promise<Task | undefined> {
    const [task] = await db
      .update(schema.tasks)
      .set(data)
      .where(eq(schema.tasks.id, id))
      .returning();
    return task;
  }

  async deleteTask(id: number): Promise<boolean> {
    const deleted = await db
      .delete(schema.tasks)
      .where(eq(schema.tasks.id, id))
      .returning({ id: schema.tasks.id });
    return deleted.length > 0;
  }

  async getTaskInputs(taskId: number): Promise<TaskInput[]> {
    return await db
      .select()
      .from(schema.taskInputs)
      .where(eq(schema.taskInputs.taskId, taskId));
  }

  async createTaskInput(data: InsertTaskInput): Promise<TaskInput> {
    const [taskInput] = await db
      .insert(schema.taskInputs)
      .values(data)
      .returning();
    return taskInput;
  }

  async deleteTaskInput(id: number): Promise<boolean> {
    const deleted = await db
      .delete(schema.taskInputs)
      .where(eq(schema.taskInputs.id, id))
      .returning({ id: schema.taskInputs.id });
    return deleted.length > 0;
  }

  async getAllSales(): Promise<Sale[]> {
    return await db.select().from(schema.sales);
  }

  async getSale(id: number): Promise<Sale | undefined> {
    const [sale] = await db.select().from(schema.sales).where(eq(schema.sales.id, id));
    return sale || undefined;
  }

  async createSale(data: InsertSale): Promise<Sale> {
    const [sale] = await db
      .insert(schema.sales)
      .values(data)
      .returning();
    return sale;
  }

  async updateSale(id: number, data: Partial<InsertSale>): Promise<Sale | undefined> {
    const [sale] = await db
      .update(schema.sales)
      .set(data)
      .where(eq(schema.sales.id, id))
      .returning();
    return sale;
  }

  async deleteSale(id: number): Promise<boolean> {
    const deleted = await db
      .delete(schema.sales)
      .where(eq(schema.sales.id, id))
      .returning({ id: schema.sales.id });
    return deleted.length > 0;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return user || undefined;
  }

  async createUser(data: InsertUser): Promise<User> {
    const [user] = await db
      .insert(schema.users)
      .values(data)
      .returning();
    return user;
  }
}

// Switch from memory storage to database storage
export const storage = new DatabaseStorage();
