import { useState, useEffect } from 'react';
import { Mic, MicOff, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

interface VoiceInputProps {
  onTextReceived: (text: string) => void;
  disabled?: boolean;
  field?: string;
}

const VoiceInput = ({ onTextReceived, disabled = false, field = 'this field' }: VoiceInputProps) => {
  const [isListening, setIsListening] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  useEffect(() => {
    // Check if browser supports speech recognition
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      // Create a speech recognition instance
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      // Configure recognition
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US'; // Default to English, can be customized
      
      // Set up event handlers
      recognitionInstance.onstart = () => {
        setIsLoading(false);
        setIsListening(true);
        toast({
          title: "Listening...",
          description: `Speak now to fill ${field}`,
        });
      };
      
      recognitionInstance.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onTextReceived(transcript);
        setIsListening(false);
        toast({
          title: "Text captured",
          description: `"${transcript.slice(0, 30)}${transcript.length > 30 ? '...' : ''}"`,
        });
      };
      
      recognitionInstance.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
        setIsLoading(false);
        toast({
          title: "Error",
          description: `Could not recognize speech: ${event.error}`,
          variant: "destructive",
        });
      };
      
      recognitionInstance.onend = () => {
        setIsListening(false);
      };
      
      setRecognition(recognitionInstance);
    }
    
    // Cleanup function
    return () => {
      if (recognition) {
        recognition.abort();
      }
    };
  }, [onTextReceived, field]);
  
  const toggleListening = () => {
    if (!recognition) {
      toast({
        title: "Not supported",
        description: "Your browser does not support speech recognition.",
        variant: "destructive",
      });
      return;
    }
    
    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      setIsLoading(true);
      try {
        recognition.start();
      } catch (error) {
        console.error('Failed to start recognition', error);
        setIsLoading(false);
        toast({
          title: "Error",
          description: "Failed to start voice recognition.",
          variant: "destructive",
        });
      }
    }
  };
  
  return (
    <Button
      type="button"
      size="icon"
      variant={isListening ? "default" : "outline"}
      onClick={toggleListening}
      disabled={disabled || isLoading}
      className="h-8 w-8 rounded-full"
      title={isListening ? "Stop listening" : "Start voice input"}
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : isListening ? (
        <Mic className="h-4 w-4 text-white" />
      ) : (
        <MicOff className="h-4 w-4" />
      )}
    </Button>
  );
};

export default VoiceInput;

// Add this to make TypeScript recognize the Web Speech API
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}