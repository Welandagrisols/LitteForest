import React from "react";
import { Link, useLocation } from "wouter";
import { Sprout, PackageOpen, ListTodo, ShoppingCart, PieChart, MessageCircle, Settings } from "lucide-react";

const Sidebar: React.FC = () => {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  return (
    <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 p-4">
      <div className="flex items-center gap-2 mb-8">
        <div className="w-8 h-8 flex items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Sprout className="h-5 w-5" />
        </div>
        <h1 className="text-xl font-semibold">LittleForest</h1>
      </div>
      
      <nav className="flex-1">
        <ul className="space-y-1">
          <li>
            <Link 
              href="/" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <PieChart className="h-5 w-5" />
              <span>Dashboard</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/species" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/species") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Sprout className="h-5 w-5" />
              <span>Species</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/inputs" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/inputs") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <PackageOpen className="h-5 w-5" />
              <span>Inputs</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/tasks" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/tasks") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <ListTodo className="h-5 w-5" />
              <span>Tasks</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/sales" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/sales") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <ShoppingCart className="h-5 w-5" />
              <span>Sales</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/reports" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/reports") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <PieChart className="h-5 w-5" />
              <span>Reports</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/whatsapp-alerts" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/whatsapp-alerts") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <MessageCircle className="h-5 w-5" />
              <span>WhatsApp Alerts</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/settings" 
              className={`flex items-center gap-3 px-4 py-3 rounded-md ${
                isActive("/settings") 
                  ? "text-gray-900 bg-gray-100" 
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Settings className="h-5 w-5" />
              <span>Settings</span>
            </Link>
          </li>
        </ul>
      </nav>
      
      <div className="mt-auto pt-4 border-t border-gray-200">
        <div className="flex items-center gap-3 px-4 py-2">
          <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
            <span className="text-gray-600 font-medium">WK</span>
          </div>
          <div>
            <p className="text-sm font-medium">Wesley Koech</p>
            <p className="text-xs text-gray-500">Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
