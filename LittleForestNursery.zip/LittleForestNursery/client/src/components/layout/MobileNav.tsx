import React from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, Sprout, ListTodo, ShoppingCart, MoreHorizontal } from "lucide-react";

const MobileNav: React.FC = () => {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
      <div className="flex justify-between px-6 py-2">
        <Link 
          href="/" 
          className={`flex flex-col items-center ${isActive("/") ? "text-primary" : "text-gray-500"}`}
        >
          <LayoutDashboard className="h-5 w-5" />
          <span className="text-xs mt-1">Dashboard</span>
        </Link>
        <Link 
          href="/species" 
          className={`flex flex-col items-center ${isActive("/species") ? "text-primary" : "text-gray-500"}`}
        >
          <Sprout className="h-5 w-5" />
          <span className="text-xs mt-1">Species</span>
        </Link>
        <Link 
          href="/tasks" 
          className={`flex flex-col items-center ${isActive("/tasks") ? "text-primary" : "text-gray-500"}`}
        >
          <ListTodo className="h-5 w-5" />
          <span className="text-xs mt-1">Tasks</span>
        </Link>
        <Link 
          href="/sales" 
          className={`flex flex-col items-center ${isActive("/sales") ? "text-primary" : "text-gray-500"}`}
        >
          <ShoppingCart className="h-5 w-5" />
          <span className="text-xs mt-1">Sales</span>
        </Link>
        <Link 
          href="/reports" 
          className={`flex flex-col items-center ${isActive("/reports") ? "text-primary" : "text-gray-500"}`}
        >
          <MoreHorizontal className="h-5 w-5" />
          <span className="text-xs mt-1">More</span>
        </Link>
      </div>
    </nav>
  );
};

export default MobileNav;
