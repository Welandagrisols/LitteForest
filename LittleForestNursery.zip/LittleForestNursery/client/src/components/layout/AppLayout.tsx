import React from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import MobileNav from "./MobileNav";
import { useLocation } from "wouter";

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const [location] = useLocation();
  
  // Get page title based on current route
  const getPageTitle = () => {
    switch (location) {
      case "/":
        return "Dashboard";
      case "/species":
        return "Species";
      case "/inputs":
        return "Inputs";
      case "/tasks":
        return "Tasks";
      case "/sales":
        return "Sales";
      case "/reports":
        return "Reports";
      case "/whatsapp-alerts":
        return "WhatsApp Alerts";
      case "/settings":
        return "Settings";
      default:
        return "LittleForest";
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      {/* Sidebar - Hidden on mobile, visible on tablet/desktop */}
      <Sidebar />
      
      {/* Main Content */}
      <main className="flex-1 overflow-auto pb-16 md:pb-0">
        {/* Top Bar */}
        <Header pageTitle={getPageTitle()} />
        
        {/* Page Content */}
        <div className="p-4 md:p-6">
          {children}
        </div>
      </main>
      
      {/* Mobile Navigation - Only visible on mobile */}
      <MobileNav />
    </div>
  );
};

export default AppLayout;
