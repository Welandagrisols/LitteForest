import React from "react";
import { Link } from "wouter";
import { Sprout, Bell } from "lucide-react";

interface HeaderProps {
  pageTitle: string;
}

const Header: React.FC<HeaderProps> = ({ pageTitle }) => {
  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-2 md:hidden">
        <div className="w-8 h-8 flex items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Sprout className="h-5 w-5" />
        </div>
        <h1 className="text-xl">
          <span style={{ color: '#FF7F00' }}>Little</span>
          <span style={{ color: '#228B22' }}>Forest</span>
        </h1>
      </div>
      <h1 className="text-xl font-semibold hidden md:block">{pageTitle}</h1>
      <div className="flex items-center gap-3">
        <button className="text-gray-500 hover:text-gray-700">
          <Bell className="h-5 w-5" />
        </button>
        <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center md:hidden">
          <span className="text-gray-600 text-xs font-medium">WK</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
