import { useQuery } from "@tanstack/react-query";
import { format, subDays, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { Sale, Task, Species, Input } from "@shared/schema";

interface ProfitabilityItem {
  speciesId: number;
  name: string;
  scientificName: string;
  quantitySold: number;
  revenue: number;
  profitPercentage: number;
}

interface OverviewData {
  totalInventory: number;
  openTasks: number;
  monthlySales: number;
  netProfit: number;
  profitability: ProfitabilityItem[];
  topSellingProduct: ProfitabilityItem | null;
}

export function useReports() {
  // Fetch overview data from the API
  const {
    data: overviewData,
    isLoading: isLoadingOverview,
    isError: isOverviewError,
    error: overviewError,
    refetch: refetchOverview
  } = useQuery<OverviewData>({
    queryKey: ["/api/reports/overview"],
  });
  
  // Fetch raw data for custom reports
  const { data: speciesData } = useQuery<Species[]>({
    queryKey: ["/api/species"],
  });
  
  const { data: inputsData } = useQuery<Input[]>({
    queryKey: ["/api/inputs"],
  });
  
  const { data: tasksData } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });
  
  const { data: salesData } = useQuery<Sale[]>({
    queryKey: ["/api/sales"],
  });
  
  // Generate dashboard metrics
  const getDashboardMetrics = () => {
    return {
      totalInventory: overviewData?.totalInventory || 0,
      openTasks: overviewData?.openTasks || 0,
      monthlySales: overviewData?.monthlySales || 0,
      netProfit: overviewData?.netProfit || 0
    };
  };
  
  // Calculate inventory value
  const getInventoryValue = () => {
    if (!speciesData) return 0;
    
    // This is an estimate - in a real app we would have cost information for species
    return speciesData.reduce((sum, species) => {
      // Assuming an average value of KSh 100 per plant
      return sum + (species.quantity * 100);
    }, 0);
  };
  
  // Calculate costs breakdown
  const getCostsBreakdown = () => {
    if (!tasksData) return { laborCosts: 0, inputsCosts: 0, totalCosts: 0 };
    
    const laborCosts = tasksData.reduce((sum, task) => sum + Number(task.laborCost), 0);
    const inputsCosts = tasksData.reduce((sum, task) => sum + Number(task.inputsCost), 0);
    
    return {
      laborCosts,
      inputsCosts,
      totalCosts: laborCosts + inputsCosts
    };
  };
  
  // Get sales trends for a period
  const getSalesTrends = (period: "week" | "month" | "quarter" | "year") => {
    if (!salesData || salesData.length === 0) return [];
    
    let days: number;
    let label: string;
    
    switch (period) {
      case "week":
        days = 7;
        label = "Last 7 days";
        break;
      case "month":
        days = 30;
        label = "Last 30 days";
        break;
      case "quarter":
        days = 90;
        label = "Last 90 days";
        break;
      case "year":
        days = 365;
        label = "Last year";
        break;
    }
    
    const startDate = subDays(new Date(), days);
    const filteredSales = salesData.filter(sale => new Date(sale.date) >= startDate);
    
    const totalRevenue = filteredSales.reduce((sum, sale) => sum + Number(sale.totalRevenue), 0);
    const totalQuantity = filteredSales.reduce((sum, sale) => sum + sale.quantity, 0);
    
    return {
      period: label,
      startDate,
      endDate: new Date(),
      totalRevenue,
      totalQuantity,
      averageSale: filteredSales.length > 0 ? totalRevenue / filteredSales.length : 0
    };
  };
  
  // Get month-over-month comparison
  const getMonthComparison = () => {
    if (!salesData || salesData.length === 0) return null;
    
    const now = new Date();
    const currentMonthStart = startOfMonth(now);
    const currentMonthEnd = endOfMonth(now);
    const lastMonthStart = startOfMonth(subMonths(now, 1));
    const lastMonthEnd = endOfMonth(subMonths(now, 1));
    
    // Current month sales
    const currentMonthSales = salesData.filter(sale => {
      const saleDate = new Date(sale.date);
      return saleDate >= currentMonthStart && saleDate <= currentMonthEnd;
    });
    
    // Last month sales
    const lastMonthSales = salesData.filter(sale => {
      const saleDate = new Date(sale.date);
      return saleDate >= lastMonthStart && saleDate <= lastMonthEnd;
    });
    
    const currentMonthRevenue = currentMonthSales.reduce((sum, sale) => sum + Number(sale.totalRevenue), 0);
    const lastMonthRevenue = lastMonthSales.reduce((sum, sale) => sum + Number(sale.totalRevenue), 0);
    
    // Calculate percentage change
    const percentageChange = lastMonthRevenue === 0 
      ? 100 
      : ((currentMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100;
    
    return {
      currentMonth: format(now, 'MMMM yyyy'),
      lastMonth: format(subMonths(now, 1), 'MMMM yyyy'),
      currentMonthRevenue,
      lastMonthRevenue,
      percentageChange
    };
  };
  
  // Get profit margin
  const getProfitMargin = () => {
    if (!overviewData || !overviewData.monthlySales || overviewData.monthlySales === 0) return 0;
    
    return (overviewData.netProfit / overviewData.monthlySales) * 100;
  };
  
  return {
    // Raw query results
    overviewData,
    isLoadingOverview,
    isOverviewError,
    overviewError,
    refetchOverview,
    
    // Raw data
    speciesData,
    inputsData,
    tasksData,
    salesData,
    
    // Report methods
    getDashboardMetrics,
    getInventoryValue,
    getCostsBreakdown,
    getSalesTrends,
    getMonthComparison,
    getProfitMargin
  };
}
