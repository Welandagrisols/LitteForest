import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Species, Input } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "./use-toast";

// Hook for working with species inventory
export function useSpeciesInventory() {
  const queryClient = useQueryClient();
  
  // Fetch all species
  const {
    data: species,
    isLoading: isLoadingSpecies,
    isError: isSpeciesError,
    error: speciesError
  } = useQuery<Species[]>({
    queryKey: ["/api/species"],
  });
  
  // Add new species
  const addSpecies = useMutation({
    mutationFn: async (newSpecies: Omit<Species, "id">) => {
      return apiRequest("POST", "/api/species", newSpecies);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/species"] });
      toast({
        title: "Species Added",
        description: "The species has been added to your inventory",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add species: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Update existing species
  const updateSpecies = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Species> }) => {
      return apiRequest("PUT", `/api/species/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/species"] });
      toast({
        title: "Species Updated",
        description: "The species has been updated in your inventory",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update species: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete species
  const deleteSpecies = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/species/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/species"] });
      toast({
        title: "Species Deleted",
        description: "The species has been removed from your inventory",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete species: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  return {
    species,
    isLoadingSpecies,
    isSpeciesError,
    speciesError,
    addSpecies,
    updateSpecies,
    deleteSpecies
  };
}

// Hook for working with non-living inventory
export function useInputsInventory() {
  const queryClient = useQueryClient();
  
  // Fetch all inputs
  const {
    data: inputs,
    isLoading: isLoadingInputs,
    isError: isInputsError,
    error: inputsError
  } = useQuery<Input[]>({
    queryKey: ["/api/inputs"],
  });
  
  // Add new input
  const addInput = useMutation({
    mutationFn: async (newInput: Omit<Input, "id">) => {
      // Calculate total cost if not provided
      if (!newInput.totalCost) {
        newInput.totalCost = Number(newInput.quantity) * Number(newInput.unitCost);
      }
      
      return apiRequest("POST", "/api/inputs", newInput);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inputs"] });
      toast({
        title: "Input Added",
        description: "The item has been added to your inventory",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add inventory item: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Update existing input
  const updateInput = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Input> }) => {
      // Recalculate total cost if quantity or unit cost changed
      if ((data.quantity !== undefined || data.unitCost !== undefined) && !data.totalCost) {
        const currentInput = inputs?.find(i => i.id === id);
        if (currentInput) {
          const quantity = data.quantity ?? currentInput.quantity;
          const unitCost = data.unitCost ?? currentInput.unitCost;
          data.totalCost = Number(quantity) * Number(unitCost);
        }
      }
      
      return apiRequest("PUT", `/api/inputs/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inputs"] });
      toast({
        title: "Input Updated",
        description: "The inventory item has been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update inventory item: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete input
  const deleteInput = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/inputs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inputs"] });
      toast({
        title: "Input Deleted",
        description: "The inventory item has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete inventory item: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Get inputs by category
  const getInputsByCategory = (category: string) => {
    return inputs?.filter(input => input.category === category) || [];
  };
  
  // Get low stock inputs
  const getLowStockInputs = (threshold = 10) => {
    return inputs?.filter(input => Number(input.quantity) <= threshold) || [];
  };
  
  return {
    inputs,
    isLoadingInputs,
    isInputsError,
    inputsError,
    addInput,
    updateInput,
    deleteInput,
    getInputsByCategory,
    getLowStockInputs
  };
}
