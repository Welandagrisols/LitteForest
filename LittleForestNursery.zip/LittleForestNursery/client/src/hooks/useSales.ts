import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sale, Species } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "./use-toast";

export function useSales() {
  const queryClient = useQueryClient();
  
  // Fetch all sales
  const {
    data: sales,
    isLoading,
    isError,
    error
  } = useQuery<Sale[]>({
    queryKey: ["/api/sales"],
  });
  
  // Fetch a specific sale
  const getSale = (saleId: number) => {
    return useQuery<Sale>({
      queryKey: [`/api/sales/${saleId}`],
      enabled: !!saleId
    });
  };
  
  // Add new sale
  const addSale = useMutation({
    mutationFn: async (newSale: Omit<Sale, "id">) => {
      // Calculate total revenue if not provided
      if (!newSale.totalRevenue) {
        newSale.totalRevenue = Number(newSale.quantity) * Number(newSale.unitPrice);
      }
      
      return apiRequest("POST", "/api/sales", newSale);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/species"] }); // Refresh species count
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Sale Recorded",
        description: "The sale has been successfully recorded",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to record sale: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Update existing sale
  const updateSale = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Sale> }) => {
      // Recalculate total revenue if quantity or unit price changed
      if ((data.quantity !== undefined || data.unitPrice !== undefined) && !data.totalRevenue) {
        const currentSale = sales?.find(s => s.id === id);
        if (currentSale) {
          const quantity = data.quantity ?? currentSale.quantity;
          const unitPrice = data.unitPrice ?? currentSale.unitPrice;
          data.totalRevenue = Number(quantity) * Number(unitPrice);
        }
      }
      
      return apiRequest("PUT", `/api/sales/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/species"] }); // Refresh species count
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Sale Updated",
        description: "The sale record has been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update sale: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete sale
  const deleteSale = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/sales/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/species"] }); // Refresh species count
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Sale Deleted",
        description: "The sale record has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete sale: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Get sales by species
  const getSalesBySpecies = (speciesId: number) => {
    return sales?.filter(sale => sale.speciesId === speciesId) || [];
  };
  
  // Get total revenue
  const getTotalRevenue = () => {
    return sales?.reduce((sum, sale) => sum + Number(sale.totalRevenue), 0) || 0;
  };
  
  // Get sales by period
  const getSalesByPeriod = (startDate: Date, endDate: Date) => {
    return sales?.filter(sale => {
      const saleDate = new Date(sale.date);
      return saleDate >= startDate && saleDate <= endDate;
    }) || [];
  };

  // Get revenue by period
  const getRevenueByPeriod = (period: "daily" | "weekly" | "monthly" | "yearly") => {
    if (!sales || sales.length === 0) return [];
    
    const result: { period: string; revenue: number }[] = [];
    const salesMap = new Map<string, number>();
    
    sales.forEach(sale => {
      const date = new Date(sale.date);
      let key = "";
      
      switch (period) {
        case "daily":
          key = date.toISOString().split('T')[0]; // YYYY-MM-DD
          break;
        case "weekly":
          // Get the week number of the year
          const weekNumber = Math.ceil((date.getDate() + new Date(date.getFullYear(), date.getMonth(), 1).getDay()) / 7);
          key = `${date.getFullYear()}-W${weekNumber}`;
          break;
        case "monthly":
          key = `${date.getFullYear()}-${date.getMonth() + 1}`;
          break;
        case "yearly":
          key = `${date.getFullYear()}`;
          break;
      }
      
      const currentRevenue = salesMap.get(key) || 0;
      salesMap.set(key, currentRevenue + Number(sale.totalRevenue));
    });
    
    // Convert map to array
    salesMap.forEach((revenue, period) => {
      result.push({ period, revenue });
    });
    
    // Sort by period
    return result.sort((a, b) => a.period.localeCompare(b.period));
  };
  
  return {
    sales,
    isLoading,
    isError,
    error,
    getSale,
    addSale,
    updateSale,
    deleteSale,
    getSalesBySpecies,
    getTotalRevenue,
    getSalesByPeriod,
    getRevenueByPeriod
  };
}
