import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Task, TaskInput } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "./use-toast";

export interface TaskWithInputs {
  task: Task;
  taskInputs: TaskInput[];
}

export function useTasks() {
  const queryClient = useQueryClient();
  
  // Fetch all tasks
  const {
    data: tasks,
    isLoading,
    isError,
    error
  } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });
  
  // Fetch a specific task with inputs
  const getTask = (taskId: number) => {
    return useQuery<TaskWithInputs>({
      queryKey: [`/api/tasks/${taskId}`],
      enabled: !!taskId
    });
  };
  
  // Add new task
  const addTask = useMutation({
    mutationFn: async (data: {
      task: Omit<Task, "id">;
      inputs: Omit<TaskInput, "id" | "taskId">[];
    }) => {
      return apiRequest("POST", "/api/tasks", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Task Added",
        description: "The task has been added to your schedule",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add task: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Update existing task
  const updateTask = useMutation({
    mutationFn: async ({ 
      id, 
      data 
    }: { 
      id: number; 
      data: {
        task: Partial<Task>;
        inputs?: Omit<TaskInput, "id">[];
      }
    }) => {
      return apiRequest("PUT", `/api/tasks/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Task Updated",
        description: "The task has been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update task: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Complete a task
  const completeTask = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("PUT", `/api/tasks/${id}`, { status: "Done" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Task Completed",
        description: "The task has been marked as complete",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update task status: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete task
  const deleteTask = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Task Deleted",
        description: "The task has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete task: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Get pending tasks
  const getPendingTasks = () => {
    return tasks?.filter(task => task.status === "Pending") || [];
  };
  
  // Get completed tasks
  const getCompletedTasks = () => {
    return tasks?.filter(task => task.status === "Done") || [];
  };
  
  // Get tasks due soon (within the next X days)
  const getTasksDueSoon = (days = 7) => {
    if (!tasks) return [];
    
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);
    
    return tasks.filter(task => {
      if (!task.dueDate || task.status === "Done") return false;
      
      const dueDate = new Date(task.dueDate);
      return dueDate >= today && dueDate <= futureDate;
    });
  };
  
  return {
    tasks,
    isLoading,
    isError,
    error,
    getTask,
    addTask,
    updateTask,
    completeTask,
    deleteTask,
    getPendingTasks,
    getCompletedTasks,
    getTasksDueSoon
  };
}
