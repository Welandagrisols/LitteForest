/**
 * Utility for exporting data to CSV format
 */

/**
 * Convert an array of objects to CSV and trigger download
 * @param data Array of objects to convert to CSV
 * @param filename Name of the file to download
 */
export function exportToCSV(data: Record<string, any>[], filename: string): void {
  if (!data || !data.length) {
    console.error("No data to export");
    return;
  }
  
  try {
    // Get headers from the first object
    const headers = Object.keys(data[0]);
    
    // Create CSV rows
    const csvRows = [];
    
    // Add header row
    csvRows.push(headers.join(','));
    
    // Add data rows
    for (const row of data) {
      const values = headers.map(header => {
        const value = row[header];
        
        // Handle special cases
        if (value === null || value === undefined) {
          return '';
        }
        
        // Format date objects
        if (value instanceof Date) {
          return `"${value.toISOString()}"`;
        }
        
        // Format strings with special characters
        if (typeof value === 'string') {
          // Escape quotes and wrap in quotes if contains commas or quotes
          const escaped = value.replace(/"/g, '""');
          return /[",\n\r]/.test(value) ? `"${escaped}"` : escaped;
        }
        
        return String(value);
      });
      
      csvRows.push(values.join(','));
    }
    
    // Combine rows into a CSV string
    const csvString = csvRows.join('\n');
    
    // Create a blob
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    
    // Create a download link
    const link = document.createElement('a');
    
    // Create a URL for the blob
    const url = URL.createObjectURL(blob);
    
    // Set link properties
    link.setAttribute('href', url);
    link.setAttribute('download', filename || 'export.csv');
    link.style.visibility = 'hidden';
    
    // Append to DOM, click, and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Release the URL
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error("Error exporting to CSV:", error);
  }
}

/**
 * Handle specific data types for CSV export
 */
export function prepareDataForCSV(data: any[], transformers?: Record<string, (value: any) => string>): Record<string, any>[] {
  if (!data || !data.length) return [];
  
  return data.map(item => {
    const processedItem: Record<string, any> = {};
    
    for (const [key, value] of Object.entries(item)) {
      // Apply custom transformer if provided
      if (transformers && transformers[key]) {
        processedItem[key] = transformers[key](value);
        continue;
      }
      
      // Default processing based on value type
      if (value instanceof Date) {
        processedItem[key] = value.toISOString().split('T')[0]; // YYYY-MM-DD
      } else if (typeof value === 'number') {
        processedItem[key] = value;
      } else if (typeof value === 'boolean') {
        processedItem[key] = value ? 'Yes' : 'No';
      } else if (value === null || value === undefined) {
        processedItem[key] = '';
      } else {
        processedItem[key] = value;
      }
    }
    
    return processedItem;
  });
}

/**
 * Export multiple related tables to CSV files with a common prefix
 */
export function exportMultipleTablesToCSV(
  dataMap: Record<string, { data: Record<string, any>[], filename: string }>
): void {
  for (const [key, { data, filename }] of Object.entries(dataMap)) {
    if (data && data.length > 0) {
      exportToCSV(data, filename);
    }
  }
}
