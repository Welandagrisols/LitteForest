/**
 * Utility functions for formatting data for display
 */

// Format currency values
export function formatCurrency(value: number, currencySymbol: string = "KSh", decimalPlaces: number = 2): string {
  return `${currencySymbol} ${value.toFixed(decimalPlaces)}`;
}

// Format percentage values
export function formatPercentage(value: number, decimalPlaces: number = 1): string {
  return `${value.toFixed(decimalPlaces)}%`;
}

// Format date to display format
export function formatDate(date: Date | string, format: string = "MMM d, yyyy"): string {
  if (!date) return "";
  
  const d = typeof date === "string" ? new Date(date) : date;
  
  // Handle invalid dates
  if (isNaN(d.getTime())) return "";
  
  // Simple formatter supporting basic formats
  switch (format) {
    case "MMM d, yyyy":
      return `${getMonthShort(d.getMonth())} ${d.getDate()}, ${d.getFullYear()}`;
    case "MM/dd/yyyy":
      return `${padZero(d.getMonth() + 1)}/${padZero(d.getDate())}/${d.getFullYear()}`;
    case "dd/MM/yyyy":
      return `${padZero(d.getDate())}/${padZero(d.getMonth() + 1)}/${d.getFullYear()}`;
    case "yyyy-MM-dd":
      return `${d.getFullYear()}-${padZero(d.getMonth() + 1)}-${padZero(d.getDate())}`;
    default:
      return `${getMonthShort(d.getMonth())} ${d.getDate()}, ${d.getFullYear()}`;
  }
}

// Helper function to pad zeros for dates
function padZero(num: number): string {
  return num < 10 ? `0${num}` : `${num}`;
}

// Helper function to get short month name
function getMonthShort(monthIndex: number): string {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return months[monthIndex];
}

// Format quantity with unit
export function formatQuantity(quantity: number, unit: string = ""): string {
  return unit ? `${quantity} ${unit}` : `${quantity}`;
}

// Format large numbers with K, M, B suffixes
export function formatLargeNumber(num: number): string {
  if (num >= 1000000000) {
    return `${(num / 1000000000).toFixed(1)}B`;
  }
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`;
  }
  return num.toString();
}

// Truncate text to a specific length with ellipsis
export function truncateText(text: string, maxLength: number): string {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
}

// Format time period for reports
export function formatTimePeriod(startDate: Date, endDate: Date): string {
  return `${formatDate(startDate)} to ${formatDate(endDate)}`;
}

// Format phone number to international format
export function formatPhoneNumber(phoneNumber: string): string {
  // Simple formatter, in a real app we would use a library like libphonenumber-js
  if (!phoneNumber) return "";
  
  // Remove all non-digit characters
  const digits = phoneNumber.replace(/\D/g, "");
  
  // Format based on length
  if (digits.length === 10) {
    // Assume local format
    return `+254 ${digits.substring(0, 3)} ${digits.substring(3, 6)} ${digits.substring(6, 10)}`;
  } else if (digits.length > 10) {
    // Assume international format
    return `+${digits.substring(0, digits.length - 9)} ${digits.substring(digits.length - 9, digits.length - 6)} ${digits.substring(digits.length - 6, digits.length - 3)} ${digits.substring(digits.length - 3)}`;
  }
  
  // Return as is if can't format
  return phoneNumber;
}

// Format a task status into a display string
export function formatTaskStatus(status: string): string {
  switch (status.toLowerCase()) {
    case "pending":
      return "Pending";
    case "done":
      return "Completed";
    default:
      return status.charAt(0).toUpperCase() + status.slice(1);
  }
}

// Format a duration in hours to a readable string
export function formatDuration(hours: number): string {
  if (hours < 1) {
    return `${Math.round(hours * 60)} minutes`;
  } else if (hours === 1) {
    return "1 hour";
  } else if (hours % 1 === 0) {
    return `${hours} hours`;
  } else {
    const fullHours = Math.floor(hours);
    const minutes = Math.round((hours - fullHours) * 60);
    return `${fullHours} hour${fullHours !== 1 ? "s" : ""} ${minutes} minute${minutes !== 1 ? "s" : ""}`;
  }
}
