/**
 * Utility functions for calculations used throughout the application
 */

// Calculate total cost of inventory inputs
export function calculateTotalCost(quantity: number, unitCost: number): number {
  return quantity * unitCost;
}

// Calculate total revenue from sales
export function calculateTotalRevenue(quantity: number, unitPrice: number): number {
  return quantity * unitPrice;
}

// Calculate labor cost based on hours and hourly rate
export function calculateLaborCost(hours: number, hourlyRate: number = 10): number {
  return hours * hourlyRate;
}

// Calculate profit margin
export function calculateProfitMargin(revenue: number, cost: number): number {
  if (revenue === 0) return 0;
  return ((revenue - cost) / revenue) * 100;
}

// Calculate profit amount
export function calculateProfit(revenue: number, cost: number): number {
  return revenue - cost;
}

// Calculate return on investment (ROI)
export function calculateROI(profit: number, cost: number): number {
  if (cost === 0) return 0;
  return (profit / cost) * 100;
}

// Calculate percentage change between two values
export function calculatePercentageChange(currentValue: number, previousValue: number): number {
  if (previousValue === 0) return currentValue > 0 ? 100 : 0;
  return ((currentValue - previousValue) / previousValue) * 100;
}

// Calculate inventory turnover rate
export function calculateInventoryTurnover(costOfGoodsSold: number, averageInventoryValue: number): number {
  if (averageInventoryValue === 0) return 0;
  return costOfGoodsSold / averageInventoryValue;
}

// Calculate days of inventory on hand
export function calculateDaysOfInventory(inventoryTurnover: number): number {
  if (inventoryTurnover === 0) return 0;
  return 365 / inventoryTurnover;
}

// Calculate projected stock depletion date
export function calculateStockDepletionDate(currentQuantity: number, averageDailyUsage: number): Date | null {
  if (averageDailyUsage <= 0 || currentQuantity <= 0) return null;
  
  const daysRemaining = currentQuantity / averageDailyUsage;
  const today = new Date();
  const depletionDate = new Date(today);
  depletionDate.setDate(today.getDate() + Math.floor(daysRemaining));
  
  return depletionDate;
}

// Check if stock is low based on threshold
export function isLowStock(currentQuantity: number, threshold: number): boolean {
  return currentQuantity <= threshold;
}

// Calculate a weighted average
export function calculateWeightedAverage(values: number[], weights: number[]): number {
  if (values.length === 0 || values.length !== weights.length) return 0;
  
  const weightedSum = values.reduce((sum, value, index) => sum + value * weights[index], 0);
  const weightSum = weights.reduce((sum, weight) => sum + weight, 0);
  
  if (weightSum === 0) return 0;
  return weightedSum / weightSum;
}
