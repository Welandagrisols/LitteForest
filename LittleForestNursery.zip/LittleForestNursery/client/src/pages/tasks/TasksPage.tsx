import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ListTodo, 
  PlusCircle, 
  Download, 
  Pencil, 
  ClipboardCheck, 
  Trash2,
  Calendar,
  Clock,
  DollarSign,
  ListTree
} from "lucide-react";
import { useLocation } from "wouter";
import AddTaskModal from "./AddTaskModal";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { exportToCSV } from "@/utils/csvExport";
import { toast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

const TasksPage: React.FC = () => {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(location.includes("?action=add"));
  const [editingTask, setEditingTask] = useState<number | null>(null);
  
  const { data: tasksData, isLoading } = useQuery({
    queryKey: ["/api/tasks"],
  });
  
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task deleted",
        description: "The task has been successfully removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete task: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const completeTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PUT", `/api/tasks/${id}`, { status: "Done" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task completed",
        description: "The task has been marked as complete",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update task status: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle add/edit modal
  const handleAddNew = () => {
    setEditingTask(null);
    setShowAddModal(true);
  };
  
  const handleEdit = (id: number) => {
    setEditingTask(id);
    setShowAddModal(true);
  };
  
  const closeModal = () => {
    setShowAddModal(false);
    setEditingTask(null);
    // Clear the query parameter if it exists
    if (location.includes("?action=add")) {
      setLocation("/tasks");
    }
  };
  
  // Handle export to CSV
  const handleExport = () => {
    if (tasksData && tasksData.length > 0) {
      const csvData = tasksData.map(task => ({
        'Task Name': task.name,
        'Species Involved': task.speciesInvolved || '',
        'Date': format(new Date(task.date), 'yyyy-MM-dd'),
        'Labor Hours': task.laborHours,
        'Labor Cost': task.laborCost,
        'Inputs Cost': task.inputsCost,
        'Total Cost': task.totalCost,
        'Status': task.status,
        'Due Date': task.dueDate ? format(new Date(task.dueDate), 'yyyy-MM-dd') : '',
        'Assigned To': task.assignedTo || '',
        'Notes': task.notes || ''
      }));
      
      exportToCSV(csvData, 'nursery-tasks.csv');
    } else {
      toast({
        title: "No data to export",
        description: "There are no tasks to export.",
        variant: "destructive",
      });
    }
  };
  
  // Handle delete
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this task? This action cannot be undone.")) {
      deleteTaskMutation.mutate(id);
    }
  };
  
  // Handle complete task
  const handleComplete = (id: number) => {
    completeTaskMutation.mutate(id);
  };
  
  const renderStatusBadge = (status: string) => {
    if (status === "Done") {
      return <Badge className="bg-primary hover:bg-primary/80">Completed</Badge>;
    } else {
      return <Badge className="bg-secondary hover:bg-secondary/80">Pending</Badge>;
    }
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Nursery Tasks</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </Button>
          <Button 
            className="flex items-center gap-2"
            onClick={handleAddNew}
          >
            <PlusCircle className="h-4 w-4" />
            <span className="hidden sm:inline">Add Task</span>
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg">Task Log & Schedule</CardTitle>
          <div>
            <Button variant="ghost" size="sm" className="text-xs">
              All
            </Button>
            <Button variant="ghost" size="sm" className="text-xs">
              Pending
            </Button>
            <Button variant="ghost" size="sm" className="text-xs">
              Completed
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading ? (
              <div className="py-6 text-center">Loading tasks...</div>
            ) : !tasksData || tasksData.length === 0 ? (
              <div className="py-8 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                  <ListTodo className="h-8 w-8 text-gray-400" />
                </div>
                <p className="text-gray-500">No tasks recorded</p>
                <p className="text-sm text-gray-400">Add tasks to track your nursery operations</p>
                
                <Button 
                  className="mt-4 flex items-center gap-2"
                  onClick={handleAddNew}
                >
                  <PlusCircle className="h-4 w-4" />
                  <span>Add First Task</span>
                </Button>
              </div>
            ) : (
              <div className="grid gap-4">
                {tasksData.map((task) => (
                  <Card key={task.id} className="overflow-hidden">
                    <div className="border-l-4 border-l-secondary p-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                        <h3 className="font-medium text-lg flex items-center gap-2">
                          {task.name}
                          <span className="ml-2">{renderStatusBadge(task.status)}</span>
                        </h3>
                        <div className="flex items-center gap-2">
                          {task.status === "Pending" && (
                            <Button
                              size="sm"
                              variant="secondary"
                              className="h-8 px-2"
                              onClick={() => handleComplete(task.id)}
                            >
                              <ClipboardCheck className="h-4 w-4 mr-1" />
                              <span>Complete</span>
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 px-2"
                            onClick={() => handleEdit(task.id)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 px-2 text-destructive hover:text-destructive/90 hover:bg-destructive/10"
                            onClick={() => handleDelete(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div className="space-y-2">
                          {task.speciesInvolved && (
                            <p className="flex items-center text-gray-600">
                              <ListTree className="h-4 w-4 mr-2 text-primary" />
                              <span>Species: {task.speciesInvolved}</span>
                            </p>
                          )}
                          <p className="flex items-center text-gray-600">
                            <Calendar className="h-4 w-4 mr-2 text-accent" />
                            <span>Date: {format(new Date(task.date), "MMM d, yyyy")}</span>
                          </p>
                          {task.dueDate && (
                            <p className="flex items-center text-gray-600">
                              <Calendar className="h-4 w-4 mr-2 text-secondary" />
                              <span>Due: {format(new Date(task.dueDate), "MMM d, yyyy")}</span>
                            </p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <p className="flex items-center text-gray-600">
                            <Clock className="h-4 w-4 mr-2 text-gray-500" />
                            <span>Labor: {task.laborHours} hours (KSh {Number(task.laborCost).toFixed(2)})</span>
                          </p>
                          <p className="flex items-center text-gray-600">
                            <DollarSign className="h-4 w-4 mr-2 text-green-500" />
                            <span>Total Cost: KSh {Number(task.totalCost).toFixed(2)}</span>
                          </p>
                          {task.assignedTo && (
                            <p className="flex items-center text-gray-600">
                              <span className="mr-2">👤</span>
                              <span>Assigned to: {task.assignedTo}</span>
                            </p>
                          )}
                        </div>
                      </div>
                      
                      {task.notes && (
                        <div className="mt-2 text-sm text-gray-600">
                          <p className="font-medium">Notes:</p>
                          <p className="italic">{task.notes}</p>
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Add/Edit Task Modal */}
      {showAddModal && (
        <AddTaskModal 
          open={showAddModal} 
          onClose={closeModal} 
          taskId={editingTask} 
        />
      )}
    </>
  );
};

export default TasksPage;
