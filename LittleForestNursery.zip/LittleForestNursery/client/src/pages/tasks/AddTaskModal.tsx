import React, { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";

// Define form schema
const formSchema = z.object({
  name: z.string().min(2, "Task name must be at least 2 characters"),
  speciesId: z.coerce.number().optional(),
  speciesInvolved: z.string().optional(),
  date: z.string(),
  numWorkers: z.coerce.number().min(1, "Number of workers must be at least 1"),
  hourlyRate: z.coerce.number().min(0, "Hourly rate cannot be negative"),
  laborHours: z.coerce.number().min(0, "Labor hours must be 0 or more"),
  laborCost: z.coerce.number().optional(),
  notes: z.string().optional(),
  status: z.string().default("Pending"),
  dueDate: z.string().optional(),
  assignedTo: z.string().optional(),
  // We'll handle the inputs separately
});

type FormValues = z.infer<typeof formSchema>;

interface AddTaskModalProps {
  open: boolean;
  onClose: () => void;
  taskId: number | null;
}

const AddTaskModal: React.FC<AddTaskModalProps> = ({ open, onClose, taskId }) => {
  const queryClient = useQueryClient();
  const isEditing = taskId !== null;
  const [selectedInputs, setSelectedInputs] = useState<any[]>([]);

  // Fetch species data for dropdown
  const { data: speciesData } = useQuery({
    queryKey: ["/api/species"],
  });

  // Fetch inputs data for dropdown
  const { data: inputsData } = useQuery({
    queryKey: ["/api/inputs"],
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      speciesInvolved: "",
      date: format(new Date(), "yyyy-MM-dd"),
      laborHours: 0,
      laborCost: 0,
      notes: "",
      status: "Pending",
      dueDate: "",
      assignedTo: "",
    },
  });

  // Watch laborHours to calculate laborCost
  const laborHours = form.watch("laborHours");

  // Update laborCost when laborHours changes
  useEffect(() => {
    const hourlyRate = 10; // Default hourly rate
    const cost = laborHours * hourlyRate;
    form.setValue("laborCost", cost);
  }, [laborHours, form]);

  // Fetch task data if editing
  const { data: taskData, isLoading: isLoadingTask } = useQuery({
    queryKey: [`/api/tasks/${taskId}`],
    enabled: isEditing,
  });

  // Update form values when task data is loaded
  useEffect(() => {
    if (isEditing && taskData) {
      const task = taskData.task;
      form.reset({
        name: task.name,
        speciesInvolved: task.speciesInvolved || "",
        date: format(new Date(task.date), "yyyy-MM-dd"),
        laborHours: Number(task.laborHours),
        laborCost: Number(task.laborCost),
        notes: task.notes || "",
        status: task.status,
        dueDate: task.dueDate ? format(new Date(task.dueDate), "yyyy-MM-dd") : "",
        assignedTo: task.assignedTo || "",
        speciesId: task.speciesId
      });

      // Set selected inputs if any
      if (taskData.taskInputs && taskData.taskInputs.length > 0) {
        setSelectedInputs(taskData.taskInputs);
      }
    }
  }, [taskData, form, isEditing]);

  // Handle selecting/deselecting inputs
  const toggleInputSelection = (input: any) => {
    const isSelected = selectedInputs.some(i => i.inputId === input.id);

    if (isSelected) {
      setSelectedInputs(selectedInputs.filter(i => i.inputId !== input.id));
    } else {
      setSelectedInputs([
        ...selectedInputs,
        {
          inputId: input.id,
          quantity: 1,
          cost: Number(input.unitCost)
        }
      ]);
    }
  };

  // Handle updating input quantity
  const updateInputQuantity = (inputId: number, quantity: number) => {
    setSelectedInputs(
      selectedInputs.map(input => {
        if (input.inputId === inputId) {
          const matchedInput = inputsData?.find(i => i.id === inputId);
          const cost = matchedInput ? Number(matchedInput.unitCost) * quantity : input.cost;
          return { ...input, quantity, cost };
        }
        return input;
      })
    );
  };

  // Create or update mutation
  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      // Calculate total cost of selected inputs
      const inputsCost = selectedInputs.reduce((sum, input) => sum + Number(input.cost), 0);
      const totalCost = Number(values.laborCost) + inputsCost;

      // Convert numeric values to strings for API submission
      const taskPayload = {
        task: {
          ...values,
          laborHours: String(values.laborHours),
          laborCost: String(values.laborCost),
          inputsCost: String(inputsCost),
          totalCost: String(totalCost)
        },
        inputs: selectedInputs.map(input => ({
          ...input,
          quantity: String(input.quantity),
          cost: String(input.cost)
        }))
      };

      if (isEditing) {
        return apiRequest("PUT", `/api/tasks/${taskId}`, taskPayload);
      } else {
        return apiRequest("POST", "/api/tasks", taskPayload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: isEditing ? "Task Updated" : "Task Added",
        description: isEditing 
          ? "The task has been successfully updated" 
          : "New task has been added to the log",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "add"} task: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Form submit handler
  const onSubmit = (values: FormValues) => {
    console.log("Submitting task data:", values);
    mutation.mutate(values);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Task" : "Add New Task"}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? "Update the details of an existing nursery task" 
              : "Enter details to log a new nursery operation"}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Task Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Transplant Seedlings" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="speciesId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Species Involved (Optional)</FormLabel>
                  <Select 
                    onValueChange={(value) => {
                      const selectedSpecies = speciesData?.find(s => s.id.toString() === value);
                      form.setValue("speciesId", value ? parseInt(value) : null);
                      form.setValue("speciesInvolved", selectedSpecies?.localName || "");
                    }}
                    value={field.value?.toString() || undefined}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a species" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {speciesData?.map((species) => (
                        <SelectItem key={species.id} value={species.id.toString()}>
                          {species.localName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Done">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date (Optional)</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="assignedTo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assigned To (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. John, Team A" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="laborHours"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Labor Hours</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" step="0.5" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="laborCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Labor Cost (KSh)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        readOnly 
                        disabled
                        value={field.value} 
                      />
                    </FormControl>
                    <FormDescription className="text-xs">
                      Auto-calculated at KSh 10/hour
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Inputs Used Section */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Inputs Used</h3>
              <p className="text-xs text-muted-foreground">
                Select inputs used for this task
              </p>

              {!inputsData || inputsData.length === 0 ? (
                <div className="text-sm text-gray-500 py-2">
                  No inputs available. Add inputs to inventory first.
                </div>
              ) : (
                <div className="border rounded-md p-3 space-y-3">
                  {inputsData.map((input) => {
                    const isSelected = selectedInputs.some(i => i.inputId === input.id);
                    const selectedInput = selectedInputs.find(i => i.inputId === input.id);

                    return (
                      <div key={input.id} className="flex flex-col space-y-2">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id={`input-${input.id}`}
                            checked={isSelected}
                            onCheckedChange={() => toggleInputSelection(input)}
                          />
                          <label 
                            htmlFor={`input-${input.id}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {input.name} ({input.category}) - KSh {Number(input.unitCost).toFixed(2)} per {input.unit}
                          </label>
                        </div>

                        {isSelected && (
                          <div className="pl-6 flex items-center gap-2">
                            <Input
                              type="number"
                              min="0.1"
                              step="0.1"
                              className="w-20 h-8"
                              value={selectedInput?.quantity || 1}
                              onChange={(e) => updateInputQuantity(input.id, parseFloat(e.target.value))}
                            />
                            <span className="text-sm">{input.unit}</span>
                            <span className="text-sm ml-2">
                              Cost: KSh {(selectedInput?.cost || 0).toFixed(2)}
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any additional information..." 
                      rows={3} 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Total Cost Summary */}
            <div className="p-3 bg-muted rounded-md">
              <div className="flex justify-between items-center">
                <span className="font-medium">Total Cost:</span>
                <span className="font-semibold">
                  KSh {(
                    Number(form.getValues("laborCost") || 0) + 
                    selectedInputs.reduce((sum, input) => sum + Number(input.cost), 0)
                  ).toFixed(2)}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Includes labor cost and all selected inputs
              </div>
            </div>

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending || isLoadingTask}
              >
                {mutation.isPending 
                  ? "Saving..." 
                  : isEditing 
                    ? "Update Task" 
                    : "Add Task"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddTaskModal;