import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ShoppingCart, 
  PlusCircle, 
  Download, 
  Pencil, 
  Info, 
  Trash2 
} from "lucide-react";
import { useLocation } from "wouter";
import AddSaleModal from "./AddSaleModal";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { exportToCSV } from "@/utils/csvExport";
import { toast } from "@/hooks/use-toast";

const SalesPage: React.FC = () => {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(location.includes("?action=add"));
  const [editingSale, setEditingSale] = useState<number | null>(null);
  
  const { data: salesData, isLoading } = useQuery({
    queryKey: ["/api/sales"],
  });
  
  const { data: speciesData } = useQuery({
    queryKey: ["/api/species"],
  });
  
  const deleteSaleMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/sales/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/species"] }); // Refresh species count
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: "Sale deleted",
        description: "The sale record has been successfully removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete sale: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle add/edit modal
  const handleAddNew = () => {
    setEditingSale(null);
    setShowAddModal(true);
  };
  
  const handleEdit = (id: number) => {
    setEditingSale(id);
    setShowAddModal(true);
  };
  
  const closeModal = () => {
    setShowAddModal(false);
    setEditingSale(null);
    // Clear the query parameter if it exists
    if (location.includes("?action=add")) {
      setLocation("/sales");
    }
  };
  
  // Handle export to CSV
  const handleExport = () => {
    if (salesData && salesData.length > 0) {
      const csvData = salesData.map(sale => {
        const species = speciesData?.find(s => s.id === sale.speciesId);
        return {
          'Species': species?.localName || `Unknown (ID: ${sale.speciesId})`,
          'Scientific Name': species?.scientificName || '',
          'Quantity Sold': sale.quantity,
          'Unit Price': sale.unitPrice,
          'Total Revenue': sale.totalRevenue,
          'Buyer': sale.buyer || '',
          'Date': format(new Date(sale.date), 'yyyy-MM-dd'),
          'Notes': sale.notes || ''
        };
      });
      
      exportToCSV(csvData, 'sales-record.csv');
    } else {
      toast({
        title: "No data to export",
        description: "There are no sales to export.",
        variant: "destructive",
      });
    }
  };
  
  // Handle delete
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this sale record? This action cannot be undone.")) {
      deleteSaleMutation.mutate(id);
    }
  };
  
  // Get species name
  const getSpeciesName = (speciesId: number) => {
    const species = speciesData?.find(s => s.id === speciesId);
    return species?.localName || `Unknown (ID: ${speciesId})`;
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Sales Records</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </Button>
          <Button 
            className="flex items-center gap-2"
            onClick={handleAddNew}
          >
            <PlusCircle className="h-4 w-4" />
            <span className="hidden sm:inline">Record Sale</span>
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Sales History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Species</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Price</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Revenue</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Buyer</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center">Loading sales data...</td>
                  </tr>
                ) : !salesData || salesData.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center">
                      <div className="py-8">
                        <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                          <ShoppingCart className="h-8 w-8 text-gray-400" />
                        </div>
                        <p className="text-gray-500">No sales recorded</p>
                        <p className="text-sm text-gray-400">Record sales to track your revenue</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  salesData.map((sale) => (
                    <tr key={sale.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                            <ShoppingCart className="h-4 w-4 text-primary" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                              {getSpeciesName(sale.speciesId)}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{sale.quantity}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">KSh {Number(sale.unitPrice).toFixed(2)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-green-600">KSh {Number(sale.totalRevenue).toFixed(2)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{sale.buyer || "-"}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">
                          {format(new Date(sale.date), "MMM d, yyyy")}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button 
                            className="text-accent hover:text-accent/80"
                            onClick={() => handleEdit(sale.id)}
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-gray-700">
                            <Info className="h-4 w-4" />
                          </button>
                          <button 
                            className="text-destructive hover:text-destructive/80"
                            onClick={() => handleDelete(sale.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      
      {/* Add/Edit Sale Modal */}
      {showAddModal && (
        <AddSaleModal 
          open={showAddModal} 
          onClose={closeModal} 
          saleId={editingSale} 
        />
      )}
    </>
  );
};

export default SalesPage;
