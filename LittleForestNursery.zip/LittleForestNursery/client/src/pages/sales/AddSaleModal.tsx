import React, { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";

// Define form schema
const formSchema = z.object({
  speciesId: z.coerce.number(),
  quantity: z.coerce.number().int().min(1, "Quantity must be at least 1"),
  unitPrice: z.coerce.number().min(0.01, "Unit price must be greater than 0"),
  totalRevenue: z.coerce.number().optional(),
  buyer: z.string().optional(),
  date: z.string(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface AddSaleModalProps {
  open: boolean;
  onClose: () => void;
  saleId: number | null;
}

const AddSaleModal: React.FC<AddSaleModalProps> = ({ open, onClose, saleId }) => {
  const queryClient = useQueryClient();
  const isEditing = saleId !== null;

  // Fetch species data for dropdown
  const { data: speciesData, isLoading: isLoadingSpecies } = useQuery({
    queryKey: ["/api/species"],
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      speciesId: 0,
      quantity: 1,
      unitPrice: 0,
      totalRevenue: 0,
      buyer: "",
      date: format(new Date(), "yyyy-MM-dd"),
      notes: "",
    },
  });

  // Watch quantity and unitPrice to calculate totalRevenue
  const quantity = form.watch("quantity");
  const unitPrice = form.watch("unitPrice");

  // Update totalRevenue when quantity or unitPrice changes
  useEffect(() => {
    const total = quantity * unitPrice;
    form.setValue("totalRevenue", total);
  }, [quantity, unitPrice, form]);

  // Fetch sale data if editing
  const { data: saleData, isLoading: isLoadingSale } = useQuery({
    queryKey: [`/api/sales/${saleId}`],
    enabled: isEditing,
  });

  // Update form values when sale data is loaded
  useEffect(() => {
    if (isEditing && saleData) {
      form.reset({
        speciesId: saleData.speciesId,
        quantity: saleData.quantity,
        unitPrice: Number(saleData.unitPrice),
        totalRevenue: Number(saleData.totalRevenue),
        buyer: saleData.buyer || "",
        date: format(new Date(saleData.date), "yyyy-MM-dd"),
        notes: saleData.notes || "",
      });
    }
  }, [saleData, form, isEditing]);

  // Create or update mutation
  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (isEditing) {
        return apiRequest("PUT", `/api/sales/${saleId}`, values);
      } else {
        return apiRequest("POST", "/api/sales", values);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/species"] }); // Refresh species count
      queryClient.invalidateQueries({ queryKey: ["/api/reports/overview"] });
      toast({
        title: isEditing ? "Sale Updated" : "Sale Recorded",
        description: isEditing 
          ? "The sale record has been successfully updated" 
          : "New sale has been recorded",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "record"} sale: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Check if selected species has enough quantity
  const selectedSpecies = speciesData?.find(s => s.id === Number(form.getValues("speciesId")));
  const hasEnoughStock = selectedSpecies ? selectedSpecies.quantity >= quantity : false;

  // Form submit handler
  const onSubmit = (values: FormValues) => {
    // Ensure totalRevenue is calculated correctly
    const totalRevenue = values.quantity * values.unitPrice;

    // Validate quantity against available stock
    if (!isEditing && selectedSpecies && values.quantity > selectedSpecies.quantity) {
      toast({
        title: "Error",
        description: `Not enough stock. Only ${selectedSpecies.quantity} ${selectedSpecies.localName} available.`,
        variant: "destructive",
      });
      return;
    }

    // Convert numeric values to strings for API submission
    const submitData = {
      ...values,
      unitPrice: String(values.unitPrice),
      totalRevenue: String(totalRevenue)
    };

    console.log("Submitting sale data:", submitData);
    mutation.mutate(submitData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Sale Record" : "Record New Sale"}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? "Update the details of an existing sale" 
              : "Enter details to record a new sale"}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="speciesId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Species</FormLabel>
                  <Select 
                    onValueChange={(value) => field.onChange(parseInt(value))} 
                    value={field.value.toString()}
                    disabled={isEditing} // Don't allow changing species when editing
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a species" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {isLoadingSpecies ? (
                        <SelectItem value="loading" disabled>
                          Loading species...
                        </SelectItem>
                      ) : !speciesData || speciesData.length === 0 ? (
                        <SelectItem value="none" disabled>
                          No species available
                        </SelectItem>
                      ) : (
                        speciesData.map((species) => (
                          <SelectItem 
                            key={`species-${species.id}`}
                            value={species.id.toString()}
                            disabled={species.quantity === 0}
                          >
                            {species.localName} ({species.quantity} available)
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="1" 
                        {...field} 
                      />
                    </FormControl>
                    {!isEditing && selectedSpecies && (
                      <FormDescription className="text-xs">
                        {hasEnoughStock 
                          ? `${selectedSpecies.quantity} available` 
                          : <span className="text-destructive">Not enough stock!</span>}
                      </FormDescription>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="unitPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Price (KSh)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0.01" 
                        step="0.01" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="totalRevenue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Total Revenue (KSh)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      readOnly 
                      disabled
                      value={field.value} 
                    />
                  </FormControl>
                  <FormDescription className="text-xs">
                    Auto-calculated
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="buyer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Buyer (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Green Gardens Ltd" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <div className="space-y-2">
                    <FormControl>
                      <Textarea 
                        placeholder="Any additional notes about the sale..." 
                        {...field} 
                      />
                    </FormControl>
                    
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={
                  mutation.isPending || 
                  isLoadingSale || 
                  (!isEditing && !hasEnoughStock) ||
                  !form.getValues("speciesId")
                }
              >
                {mutation.isPending 
                  ? "Saving..." 
                  : isEditing 
                    ? "Update Sale" 
                    : "Record Sale"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddSaleModal;