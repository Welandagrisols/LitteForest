import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { Button } from "@/components/ui/button";
import { Download, TrendingUp, TrendingDown, DollarSign, ArrowRight } from "lucide-react";
import { exportToCSV } from "@/utils/csvExport";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

const ReportsPage: React.FC = () => {
  const [reportPeriod, setReportPeriod] = useState<"month" | "quarter" | "year">("month");
  
  // Fetch overview data
  const { data: overviewData, isLoading } = useQuery({
    queryKey: ["/api/reports/overview"],
  });
  
  // Fetch species data
  const { data: speciesData } = useQuery({
    queryKey: ["/api/species"],
  });
  
  // Fetch tasks data
  const { data: tasksData } = useQuery({
    queryKey: ["/api/tasks"],
  });
  
  // Fetch sales data
  const { data: salesData } = useQuery({
    queryKey: ["/api/sales"],
  });
  
  // Handle export report
  const handleExportReport = () => {
    if (!overviewData) {
      toast({
        title: "Error",
        description: "No data available to export",
        variant: "destructive",
      });
      return;
    }
    
    // Create profitability report
    const profitReport = overviewData.profitability.map(item => ({
      'Species': item.name,
      'Scientific Name': item.scientificName || '',
      'Quantity Sold': item.quantitySold,
      'Revenue': item.revenue,
      'Profit %': item.profitPercentage + '%'
    }));
    
    exportToCSV(profitReport, 'profitability-report.csv');
    
    toast({
      title: "Report Exported",
      description: "Profitability report has been downloaded as CSV",
    });
  };
  
  // Colors for charts
  const COLORS = [
    'hsl(var(--chart-1))',
    'hsl(var(--chart-2))',
    'hsl(var(--chart-3))',
    'hsl(var(--chart-4))',
    'hsl(var(--chart-5))'
  ];
  
  // Format currency
  const formatCurrency = (value: number) => {
    return `KSh ${value.toFixed(2)}`;
  };
  
  // Generate monthly revenue data
  const getRevenueData = () => {
    if (!salesData) return [];
    
    // Group sales by month
    const monthlySales = salesData.reduce((acc: any, sale) => {
      const month = format(new Date(sale.date), 'MMM');
      if (!acc[month]) {
        acc[month] = 0;
      }
      acc[month] += Number(sale.totalRevenue);
      return acc;
    }, {});
    
    // Convert to array for chart
    return Object.entries(monthlySales).map(([month, revenue]) => ({
      month,
      revenue
    }));
  };
  
  // Generate cost breakdown data
  const getCostBreakdownData = () => {
    if (!overviewData || !tasksData) return [];
    
    const laborCosts = tasksData.reduce((sum, task) => sum + Number(task.laborCost), 0);
    const inputCosts = tasksData.reduce((sum, task) => sum + Number(task.inputsCost), 0);
    
    return [
      { name: 'Labor', value: laborCosts },
      { name: 'Inputs', value: inputCosts }
    ];
  };
  
  // Calculate metrics
  const getTotalInventoryValue = () => {
    if (!speciesData) return 0;
    
    // This is an estimate - we don't have cost information for species
    // In a real app, we would track the cost per species
    const estimatedValue = speciesData.reduce((sum, species) => {
      // Assuming an average value of KSh 100 per plant
      return sum + (species.quantity * 100);
    }, 0);
    
    return estimatedValue;
  };
  
  const getNetProfit = () => {
    if (!overviewData) return 0;
    return overviewData.netProfit || 0;
  };
  
  const getProfitMargin = () => {
    if (!overviewData || !overviewData.monthlySales || overviewData.monthlySales === 0) return 0;
    
    return (overviewData.netProfit / overviewData.monthlySales) * 100;
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Financial Reports</h1>
        <Button 
          variant="outline" 
          className="flex items-center gap-2"
          onClick={handleExportReport}
        >
          <Download className="h-4 w-4" />
          <span>Export Report</span>
        </Button>
      </div>
      
      {/* Report Period Selector */}
      <div className="mb-6">
        <div className="inline-flex rounded-md shadow-sm">
          <Button
            variant={reportPeriod === "month" ? "default" : "outline"}
            className="rounded-l-md rounded-r-none"
            onClick={() => setReportPeriod("month")}
          >
            Monthly
          </Button>
          <Button
            variant={reportPeriod === "quarter" ? "default" : "outline"}
            className="rounded-none border-l-0 border-r-0"
            onClick={() => setReportPeriod("quarter")}
          >
            Quarterly
          </Button>
          <Button
            variant={reportPeriod === "year" ? "default" : "outline"}
            className="rounded-r-md rounded-l-none"
            onClick={() => setReportPeriod("year")}
          >
            Yearly
          </Button>
        </div>
      </div>
      
      {/* Key Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Inventory Value</p>
                <p className="text-2xl font-bold mt-1">
                  {isLoading ? "Loading..." : formatCurrency(getTotalInventoryValue())}
                </p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="flex items-center text-xs text-primary mt-2">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span>+5% from last period</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Net Profit</p>
                <p className="text-2xl font-bold mt-1">
                  {isLoading ? "Loading..." : formatCurrency(getNetProfit())}
                </p>
              </div>
              <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="flex items-center text-xs text-primary mt-2">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span>+12% from last period</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Profit Margin</p>
                <p className="text-2xl font-bold mt-1">
                  {isLoading ? "Loading..." : `${getProfitMargin().toFixed(1)}%`}
                </p>
              </div>
              <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                <ArrowRight className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center text-xs text-primary mt-2">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span>+3% from last period</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Revenue Trend */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Revenue Trend</CardTitle>
            <CardDescription>
              Monthly sales revenue 
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              {!isLoading && salesData && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={getRevenueData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => formatCurrency(Number(value))}
                      labelFormatter={(label) => `Month: ${label}`}
                    />
                    <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Cost Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Cost Breakdown</CardTitle>
            <CardDescription>
              Distribution of costs by category
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center">
              {!isLoading && tasksData && (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={getCostBreakdownData()}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {getCostBreakdownData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Profitability By Species */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Profitability By Species</CardTitle>
          <CardDescription>
            Revenue and profit contribution by plant species
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-4 text-center">Loading profitability data...</div>
          ) : !overviewData?.profitability || overviewData.profitability.length === 0 ? (
            <div className="py-8 text-center">
              <p className="text-gray-500">No profitability data available</p>
              <p className="text-sm text-gray-400">Record sales to generate profitability metrics</p>
            </div>
          ) : (
            <div className="space-y-4">
              {overviewData.profitability.map((item) => (
                <div key={item.speciesId}>
                  <div className="flex justify-between items-center mb-1">
                    <div>
                      <span className="font-medium">{item.name}</span>
                      {item.scientificName && (
                        <span className="text-xs text-gray-500 ml-2">({item.scientificName})</span>
                      )}
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm">{formatCurrency(item.revenue)}</span>
                      <span className="text-sm font-medium w-12 text-right">{item.profitPercentage}%</span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full" 
                      style={{ width: `${item.profitPercentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Profit Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Profit Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-xl font-bold mt-1">
                  {isLoading ? "Loading..." : formatCurrency(overviewData?.monthlySales || 0)}
                </p>
              </div>
              
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">Labor Costs</p>
                <p className="text-xl font-bold mt-1">
                  {isLoading ? "Loading..." : formatCurrency(tasksData?.reduce((sum, task) => sum + Number(task.laborCost), 0) || 0)}
                </p>
              </div>
              
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground">Input Costs</p>
                <p className="text-xl font-bold mt-1">
                  {isLoading ? "Loading..." : formatCurrency(tasksData?.reduce((sum, task) => sum + Number(task.inputsCost), 0) || 0)}
                </p>
              </div>
              
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-600">Net Profit</p>
                <p className="text-xl font-bold text-green-700 mt-1">
                  {isLoading ? "Loading..." : formatCurrency(getNetProfit())}
                </p>
              </div>
            </div>
            
            <div className="p-4 border rounded-lg mt-4">
              <h3 className="font-medium mb-2">Analysis</h3>
              <p className="text-sm text-gray-600">
                Based on current sales and costs, your nursery is{' '}
                {getNetProfit() > 0 ? 'profitable' : 'not yet profitable'}.{' '}
                {overviewData?.topSellingProduct ? (
                  <>
                    Your top-selling product is <strong>{overviewData.topSellingProduct.name}</strong>,
                    contributing {overviewData.topSellingProduct.profitPercentage}% to your total revenue.
                  </>
                ) : (
                  'You do not have enough sales data to identify top-performing products.'
                )}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
};

export default ReportsPage;
