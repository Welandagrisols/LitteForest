import React, { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { inputCategoryEnum } from "@shared/schema";
import { format } from "date-fns";
import VoiceInput from "@/components/VoiceInput";

// Define form schema
const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  category: z.enum([
    "Seed",
    "Fertilizer",
    "Tool",
    "Soil",
    "Chemical",
    "Container",
    "Other"
  ]),
  quantity: z.coerce.number().min(0, "Quantity must be 0 or more"),
  unit: z.string().min(1, "Unit is required"),
  unitCost: z.coerce.number().min(0, "Unit cost must be 0 or more"),
  totalCost: z.coerce.number().optional(),
  dateReceived: z.string(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface AddInputModalProps {
  open: boolean;
  onClose: () => void;
  inputId: number | null;
}

const AddInputModal: React.FC<AddInputModalProps> = ({ open, onClose, inputId }) => {
  const queryClient = useQueryClient();
  const isEditing = inputId !== null;
  
  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      category: "Seed",
      quantity: 0,
      unit: "pieces",
      unitCost: 0,
      totalCost: 0,
      dateReceived: format(new Date(), "yyyy-MM-dd"),
      notes: "",
    },
  });
  
  // Watch quantity and unitCost to calculate totalCost
  const quantity = form.watch("quantity");
  const unitCost = form.watch("unitCost");
  
  // Update totalCost when quantity or unitCost changes
  useEffect(() => {
    const total = quantity * unitCost;
    form.setValue("totalCost", total);
  }, [quantity, unitCost, form]);
  
  // Fetch input data if editing
  const { data: inputData, isLoading: isLoadingInput } = useQuery({
    queryKey: [`/api/inputs/${inputId}`],
    enabled: isEditing,
  });
  
  // Update form values when input data is loaded
  useEffect(() => {
    if (isEditing && inputData) {
      form.reset({
        name: inputData.name,
        category: inputData.category,
        quantity: Number(inputData.quantity),
        unit: inputData.unit,
        unitCost: Number(inputData.unitCost),
        totalCost: Number(inputData.totalCost),
        dateReceived: format(new Date(inputData.dateReceived), "yyyy-MM-dd"),
        notes: inputData.notes || "",
      });
    }
  }, [inputData, form, isEditing]);
  
  // Create or update mutation
  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (isEditing) {
        return apiRequest("PUT", `/api/inputs/${inputId}`, values);
      } else {
        return apiRequest("POST", "/api/inputs", values);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inputs"] });
      toast({
        title: isEditing ? "Item Updated" : "Item Added",
        description: isEditing 
          ? "The inventory item has been successfully updated" 
          : "New item has been added to the inventory",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "add"} inventory item: ${error}`,
        variant: "destructive",
      });
    },
  });
  
  // Form submit handler
  const onSubmit = (values: FormValues) => {
    // Ensure totalCost is calculated correctly
    const totalCost = values.quantity * values.unitCost;
    
    // Convert numeric values to strings for API submission
    const submitData = {
      ...values,
      quantity: String(values.quantity),
      unitCost: String(values.unitCost),
      totalCost: String(totalCost)
    };
    
    console.log("Submitting input data:", submitData);
    mutation.mutate(submitData);
  };
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Inventory Item" : "Add New Inventory Item"}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? "Update the details of an existing inventory item" 
              : "Enter details to add a new item to your non-living inventory"}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Item Name</FormLabel>
                  <div className="flex space-x-2">
                    <FormControl className="flex-1">
                      <Input placeholder="e.g. Forest Soil, Polytubes" {...field} />
                    </FormControl>
                    <VoiceInput 
                      onTextReceived={(text) => form.setValue("name", text)}
                      disabled={mutation.isPending || isLoadingInput}
                      field="name"
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {inputCategoryEnum.options.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" step="0.01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="unit"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. kg, L, pieces" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="unitCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Cost (KSh)</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" step="0.01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="totalCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Cost (KSh)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        readOnly 
                        disabled
                        value={field.value} 
                      />
                    </FormControl>
                    <FormDescription className="text-xs">
                      Auto-calculated
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="dateReceived"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date Received</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <div className="space-y-2">
                    <FormControl>
                      <Textarea 
                        placeholder="Any additional information..." 
                        rows={3} 
                        {...field} 
                      />
                    </FormControl>
                    <div className="flex justify-end">
                      <VoiceInput 
                        onTextReceived={(text) => form.setValue("notes", text)}
                        disabled={mutation.isPending || isLoadingInput}
                        field="notes"
                      />
                    </div>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending || isLoadingInput}
              >
                {mutation.isPending 
                  ? "Saving..." 
                  : isEditing 
                    ? "Update Item" 
                    : "Add Item"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddInputModal;
