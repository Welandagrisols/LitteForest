import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  PackageOpen, 
  PlusCircle, 
  Download,
  Pencil, 
  Info, 
  Trash2 
} from "lucide-react";
import { useLocation } from "wouter";
import AddInputModal from "./AddInputModal";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { exportToCSV } from "@/utils/csvExport";
import { toast } from "@/hooks/use-toast";

const InputsPage: React.FC = () => {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(location.includes("?action=add"));
  const [editingInput, setEditingInput] = useState<number | null>(null);
  
  const { data: inputsData, isLoading } = useQuery({
    queryKey: ["/api/inputs"],
  });
  
  const deleteInputMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/inputs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inputs"] });
      toast({
        title: "Input deleted",
        description: "The inventory item has been successfully removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete inventory item: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle add/edit modal
  const handleAddNew = () => {
    setEditingInput(null);
    setShowAddModal(true);
  };
  
  const handleEdit = (id: number) => {
    setEditingInput(id);
    setShowAddModal(true);
  };
  
  const closeModal = () => {
    setShowAddModal(false);
    setEditingInput(null);
    // Clear the query parameter if it exists
    if (location.includes("?action=add")) {
      setLocation("/inputs");
    }
  };
  
  // Handle export to CSV
  const handleExport = () => {
    if (inputsData && inputsData.length > 0) {
      const csvData = inputsData.map(input => ({
        'Name': input.name,
        'Category': input.category,
        'Quantity': input.quantity,
        'Unit': input.unit,
        'Unit Cost': input.unitCost,
        'Total Cost': input.totalCost,
        'Date Received': format(new Date(input.dateReceived), 'yyyy-MM-dd'),
        'Notes': input.notes || ''
      }));
      
      exportToCSV(csvData, 'inputs-inventory.csv');
    } else {
      toast({
        title: "No data to export",
        description: "There are no inventory items to export.",
        variant: "destructive",
      });
    }
  };
  
  // Handle delete
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this inventory item? This action cannot be undone.")) {
      deleteInputMutation.mutate(id);
    }
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Inputs Inventory</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </Button>
          <Button 
            className="flex items-center gap-2"
            onClick={handleAddNew}
          >
            <PlusCircle className="h-4 w-4" />
            <span className="hidden sm:inline">Add Input</span>
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Non-Living Inventory Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Cost</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Cost</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Received</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center">Loading inventory data...</td>
                  </tr>
                ) : !inputsData || inputsData.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center">
                      <div className="py-8">
                        <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                          <PackageOpen className="h-8 w-8 text-gray-400" />
                        </div>
                        <p className="text-gray-500">No inputs in inventory</p>
                        <p className="text-sm text-gray-400">Add non-living inventory items used in nursery work</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  inputsData.map((input) => (
                    <tr key={input.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <PackageOpen className="h-4 w-4 text-accent" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{input.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{input.category}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{input.quantity} {input.unit}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">KSh {Number(input.unitCost).toFixed(2)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">KSh {Number(input.totalCost).toFixed(2)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">
                          {format(new Date(input.dateReceived), "MMM d, yyyy")}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button 
                            className="text-accent hover:text-accent/80"
                            onClick={() => handleEdit(input.id)}
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-gray-700">
                            <Info className="h-4 w-4" />
                          </button>
                          <button 
                            className="text-destructive hover:text-destructive/80"
                            onClick={() => handleDelete(input.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      
      {/* Add/Edit Input Modal */}
      {showAddModal && (
        <AddInputModal 
          open={showAddModal} 
          onClose={closeModal} 
          inputId={editingInput} 
        />
      )}
    </>
  );
};

export default InputsPage;
