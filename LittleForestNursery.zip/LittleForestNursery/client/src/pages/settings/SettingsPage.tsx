import React, { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Settings, 
  User, 
  Cloud, 
  Database, 
  Save,
  AlertTriangle,
  MoreHorizontal
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

const SettingsPage: React.FC = () => {
  // Profile settings
  const [profile, setProfile] = useState({
    fullName: "Wesley Koech",
    email: "welandagrisols@gmail.com",
    role: "Admin"
  });
  
  // App settings
  const [appSettings, setAppSettings] = useState({
    darkMode: false,
    autoSave: true,
    notifications: true,
    weatherWidget: true,
    currencySymbol: "KSh",
    dateFormat: "MMM d, yyyy"
  });
  
  // Data settings
  const [dataSettings, setDataSettings] = useState({
    backupEnabled: false,
    backupFrequency: "weekly",
    lastBackup: null,
    autoExport: false
  });
  
  // Handle profile save
  const handleSaveProfile = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile information has been saved",
    });
  };
  
  // Handle app settings save
  const handleSaveAppSettings = () => {
    toast({
      title: "Settings Saved",
      description: "Your application settings have been updated",
    });
  };
  
  // Handle data backup
  const handleBackupNow = () => {
    toast({
      title: "Backup Started",
      description: "Your data backup has been initiated",
    });
    
    // Simulate backup
    setTimeout(() => {
      setDataSettings({
        ...dataSettings,
        lastBackup: new Date()
      });
      
      toast({
        title: "Backup Complete",
        description: "Your data has been successfully backed up",
      });
    }, 2000);
  };
  
  // Handle app reset
  const handleResetApp = () => {
    // This would normally show a confirmation dialog
    if (window.confirm("Are you sure you want to reset all data? This action cannot be undone.")) {
      toast({
        title: "Application Reset",
        description: "All data has been reset to defaults",
        variant: "destructive",
      });
    }
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Settings</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" /> 
              Profile Settings
            </CardTitle>
            <CardDescription>
              Manage your account information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <Label htmlFor="full-name">Full Name</Label>
              <Input 
                id="full-name" 
                value={profile.fullName}
                onChange={(e) => setProfile({...profile, fullName: e.target.value})}
              />
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="email">Email Address</Label>
              <Input 
                id="email" 
                type="email"
                value={profile.email}
                onChange={(e) => setProfile({...profile, email: e.target.value})}
              />
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="role">Role</Label>
              <Input 
                id="role" 
                value={profile.role}
                disabled
              />
              <p className="text-xs text-muted-foreground">
                Contact your administrator to change user roles
              </p>
            </div>
          </CardContent>
          <CardFooter className="border-t pt-4 flex justify-between">
            <Button variant="outline">Change Password</Button>
            <Button onClick={handleSaveProfile}>
              <Save className="h-4 w-4 mr-2" />
              Save Profile
            </Button>
          </CardFooter>
        </Card>
        
        {/* App Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" /> 
              Application Settings
            </CardTitle>
            <CardDescription>
              Customize your application experience
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between space-x-2">
              <div>
                <Label htmlFor="dark-mode" className="text-sm">Dark Mode</Label>
                <p className="text-xs text-muted-foreground">Enable dark theme for the application</p>
              </div>
              <Switch 
                id="dark-mode" 
                checked={appSettings.darkMode} 
                onCheckedChange={(checked) => setAppSettings({...appSettings, darkMode: checked})} 
              />
            </div>
            
            <div className="flex items-center justify-between space-x-2">
              <div>
                <Label htmlFor="auto-save" className="text-sm">Auto-Save</Label>
                <p className="text-xs text-muted-foreground">Automatically save changes</p>
              </div>
              <Switch 
                id="auto-save" 
                checked={appSettings.autoSave} 
                onCheckedChange={(checked) => setAppSettings({...appSettings, autoSave: checked})} 
              />
            </div>
            
            <div className="flex items-center justify-between space-x-2">
              <div>
                <Label htmlFor="notifications" className="text-sm">In-App Notifications</Label>
                <p className="text-xs text-muted-foreground">Show notifications within the app</p>
              </div>
              <Switch 
                id="notifications" 
                checked={appSettings.notifications} 
                onCheckedChange={(checked) => setAppSettings({...appSettings, notifications: checked})} 
              />
            </div>
            
            <div className="flex items-center justify-between space-x-2">
              <div>
                <Label htmlFor="weather-widget" className="text-sm">Weather Widget</Label>
                <p className="text-xs text-muted-foreground">Show weather information on dashboard</p>
              </div>
              <Switch 
                id="weather-widget" 
                checked={appSettings.weatherWidget} 
                onCheckedChange={(checked) => setAppSettings({...appSettings, weatherWidget: checked})} 
              />
            </div>
            
            <Separator className="my-2" />
            
            <div className="space-y-1">
              <Label htmlFor="currency-symbol">Currency Symbol</Label>
              <Select 
                value={appSettings.currencySymbol}
                onValueChange={(value) => setAppSettings({...appSettings, currencySymbol: value})}
              >
                <SelectTrigger id="currency-symbol">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="KSh">KSh (Kenyan Shilling)</SelectItem>
                  <SelectItem value="$">$ (US Dollar)</SelectItem>
                  <SelectItem value="€">€ (Euro)</SelectItem>
                  <SelectItem value="£">£ (British Pound)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="date-format">Date Format</Label>
              <Select 
                value={appSettings.dateFormat}
                onValueChange={(value) => setAppSettings({...appSettings, dateFormat: value})}
              >
                <SelectTrigger id="date-format">
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MMM d, yyyy">MMM d, yyyy (Apr 17, 2025)</SelectItem>
                  <SelectItem value="yyyy-MM-dd">yyyy-MM-dd (2025-04-17)</SelectItem>
                  <SelectItem value="dd/MM/yyyy">dd/MM/yyyy (17/04/2025)</SelectItem>
                  <SelectItem value="MM/dd/yyyy">MM/dd/yyyy (04/17/2025)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
          <CardFooter className="border-t pt-4 flex justify-end">
            <Button onClick={handleSaveAppSettings}>
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      {/* Data Management */}
      <div className="mt-6 grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" /> 
              Data Management
            </CardTitle>
            <CardDescription>
              Backup, restore, and manage your nursery data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between space-x-2">
                  <div>
                    <Label htmlFor="backup-enabled" className="text-sm">Automatic Backup</Label>
                    <p className="text-xs text-muted-foreground">Regularly back up your data</p>
                  </div>
                  <Switch 
                    id="backup-enabled" 
                    checked={dataSettings.backupEnabled} 
                    onCheckedChange={(checked) => setDataSettings({...dataSettings, backupEnabled: checked})} 
                  />
                </div>
                
                {dataSettings.backupEnabled && (
                  <div className="space-y-1">
                    <Label htmlFor="backup-frequency">Backup Frequency</Label>
                    <Select 
                      value={dataSettings.backupFrequency}
                      onValueChange={(value) => setDataSettings({...dataSettings, backupFrequency: value})}
                    >
                      <SelectTrigger id="backup-frequency">
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                <div className="flex items-center justify-between space-x-2">
                  <div>
                    <Label htmlFor="auto-export" className="text-sm">Auto-Export CSV</Label>
                    <p className="text-xs text-muted-foreground">Automatically export data to CSV files</p>
                  </div>
                  <Switch 
                    id="auto-export" 
                    checked={dataSettings.autoExport} 
                    onCheckedChange={(checked) => setDataSettings({...dataSettings, autoExport: checked})} 
                  />
                </div>
                
                <div className="pt-2">
                  <Button variant="outline" className="w-full" onClick={handleBackupNow}>
                    <Cloud className="h-4 w-4 mr-2" />
                    Backup Data Now
                  </Button>
                  {dataSettings.lastBackup && (
                    <p className="text-xs text-muted-foreground mt-1 text-center">
                      Last backup: {dataSettings.lastBackup.toLocaleString()}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="space-y-4 border-l pl-6">
                <h3 className="text-sm font-medium flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  Danger Zone
                </h3>
                <p className="text-sm text-muted-foreground">
                  These actions are irreversible and should be used with caution
                </p>
                
                <div className="space-y-2 pt-2">
                  <Button variant="outline" className="w-full">
                    <MoreHorizontal className="h-4 w-4 mr-2" />
                    Export All Data
                  </Button>
                  
                  <Button variant="outline" className="w-full">
                    <MoreHorizontal className="h-4 w-4 mr-2" />
                    Import Data
                  </Button>
                  
                  <Button variant="destructive" className="w-full mt-4" onClick={handleResetApp}>
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Reset All Data
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default SettingsPage;
