import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sprout, PlusCircle, Download, Pencil, Info, Trash2 } from "lucide-react";
import { useLocation } from "wouter";
import AddSpeciesModal from "./AddSpeciesModal";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { exportToCSV } from "@/utils/csvExport";
import { toast } from "@/hooks/use-toast";

const SpeciesPage: React.FC = () => {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [showAddModal, setShowAddModal] = useState(location.includes("?action=add"));
  const [editingSpecies, setEditingSpecies] = useState<number | null>(null);
  
  const { data: speciesData, isLoading } = useQuery({
    queryKey: ["/api/species"],
  });
  
  const deleteSpeciesMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/species/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/species"] });
      toast({
        title: "Species deleted",
        description: "The species has been successfully removed from inventory",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete species: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle add/edit modal
  const handleAddNew = () => {
    setEditingSpecies(null);
    setShowAddModal(true);
  };
  
  const handleEdit = (id: number) => {
    setEditingSpecies(id);
    setShowAddModal(true);
  };
  
  const closeModal = () => {
    setShowAddModal(false);
    setEditingSpecies(null);
    // Clear the query parameter if it exists
    if (location.includes("?action=add")) {
      setLocation("/species");
    }
  };
  
  // Handle export to CSV
  const handleExport = () => {
    if (speciesData && speciesData.length > 0) {
      const csvData = speciesData.map(species => ({
        'Local Name': species.localName,
        'Scientific Name': species.scientificName || '',
        'Quantity': species.quantity,
        'Establishment Date': format(new Date(species.establishmentDate), 'yyyy-MM-dd'),
        'Notes': species.notes || ''
      }));
      
      exportToCSV(csvData, 'species-inventory.csv');
    } else {
      toast({
        title: "No data to export",
        description: "There are no species in the inventory to export.",
        variant: "destructive",
      });
    }
  };
  
  // Handle delete
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this species? This action cannot be undone.")) {
      deleteSpeciesMutation.mutate(id);
    }
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Species Catalog</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={handleExport}
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </Button>
          <Button 
            className="flex items-center gap-2"
            onClick={handleAddNew}
          >
            <PlusCircle className="h-4 w-4" />
            <span className="hidden sm:inline">Add Species</span>
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Live Plants Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Species</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Scientific Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Establishment Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center">Loading species data...</td>
                  </tr>
                ) : !speciesData || speciesData.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center">
                      <div className="py-8">
                        <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                          <Sprout className="h-8 w-8 text-gray-400" />
                        </div>
                        <p className="text-gray-500">No species in inventory</p>
                        <p className="text-sm text-gray-400">Add species to track your nursery inventory</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  speciesData.map((species) => (
                    <tr key={species.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                            <Sprout className="h-4 w-4 text-primary" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{species.localName}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{species.scientificName || "-"}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{species.quantity}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">
                          {format(new Date(species.establishmentDate), "MMM d, yyyy")}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button 
                            className="text-accent hover:text-accent/80"
                            onClick={() => handleEdit(species.id)}
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-gray-700">
                            <Info className="h-4 w-4" />
                          </button>
                          <button 
                            className="text-destructive hover:text-destructive/80"
                            onClick={() => handleDelete(species.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      
      {/* Add/Edit Species Modal */}
      {showAddModal && (
        <AddSpeciesModal 
          open={showAddModal} 
          onClose={closeModal} 
          speciesId={editingSpecies} 
        />
      )}
    </>
  );
};

export default SpeciesPage;
