import React, { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
// Assuming VoiceInput component is defined elsewhere and imported
import VoiceInput from '@/components/VoiceInput'; // Replace './VoiceInput' with the actual import path


// Define form schema for form validation
const formSchema = z.object({
  localName: z.string().min(2, "Local name must be at least 2 characters"),
  scientificName: z.string().nullable().or(z.literal("")),
  quantity: z.coerce.number().int().min(0, "Quantity must be 0 or more"),
  establishmentDate: z.string(), // Keep as string for the form
  notes: z.string().nullable().or(z.literal("")),
});

type FormValues = z.infer<typeof formSchema>;

interface AddSpeciesModalProps {
  open: boolean;
  onClose: () => void;
  speciesId: number | null;
}

const AddSpeciesModal: React.FC<AddSpeciesModalProps> = ({ open, onClose, speciesId }) => {
  const queryClient = useQueryClient();
  const isEditing = speciesId !== null;

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      localName: "",
      scientificName: "", // Use empty string instead of null for form inputs
      quantity: 0,
      establishmentDate: format(new Date(), "yyyy-MM-dd"),
      notes: "", // Use empty string instead of null for form inputs
    },
  });

  // Fetch species data if editing
  const { data: speciesData, isLoading: isLoadingSpecies } = useQuery({
    queryKey: [`/api/species/${speciesId}`],
    enabled: isEditing,
  });

  // Update form values when species data is loaded
  useEffect(() => {
    if (isEditing && speciesData) {
      form.reset({
        localName: speciesData.localName,
        scientificName: speciesData.scientificName || "",
        quantity: speciesData.quantity,
        establishmentDate: format(new Date(speciesData.establishmentDate), "yyyy-MM-dd"),
        notes: speciesData.notes || "",
      });
    }
  }, [speciesData, form, isEditing]);

  // Create or update mutation
  const mutation = useMutation({
    mutationFn: async (data: any) => {
      // The data parameter already contains the transformed values from onSubmit
      if (isEditing) {
        return apiRequest("PUT", `/api/species/${speciesId}`, data);
      } else {
        return apiRequest("POST", "/api/species", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/species"] });
      toast({
        title: isEditing ? "Species Updated" : "Species Added",
        description: isEditing 
          ? "The species has been successfully updated" 
          : "New species has been added to the inventory",
      });
      onClose();
    },
    onError: (error) => {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "add"} species: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Form submit handler
  const onSubmit = (values: FormValues) => {
    // Ensure proper data format for API submission
    const submitData = {
      localName: values.localName,
      scientificName: values.scientificName === "" ? null : values.scientificName,
      quantity: values.quantity,
      establishmentDate: new Date(values.establishmentDate), // Convert string to Date object
      notes: values.notes === "" ? null : values.notes
    };

    console.log("Submitting species data:", submitData);
    mutation.mutate(submitData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Species" : "Add New Species"}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? "Update the details of an existing species in your inventory" 
              : "Enter details to add a new species to your inventory"}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="localName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Local Name</FormLabel>
                  <div className="flex space-x-2">
                    <FormControl className="flex-1">
                      <Input placeholder="e.g. Mukau, Meru Oak" {...field} />
                    </FormControl>
                    <VoiceInput 
                      onTextReceived={(text) => form.setValue("localName", text)}
                      disabled={mutation.isPending || isLoadingSpecies}
                      field="local name"
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scientificName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Scientific Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Quercus robur" {...field} />
                  </FormControl>
                  <FormDescription>
                    Scientific or botanical name (optional)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="establishmentDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Establishment Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any additional information..." 
                      rows={3} 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending || isLoadingSpecies}
              >
                {mutation.isPending 
                  ? "Saving..." 
                  : isEditing 
                    ? "Update Species" 
                    : "Add Species"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddSpeciesModal;