import React, { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  MessageCircle, 
  Plus, 
  Clock, 
  Bell, 
  Check, 
  Settings, 
  Phone, 
  AlertTriangle 
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

const WhatsAppAlertsPage: React.FC = () => {
  const [phoneNumber, setPhoneNumber] = useState("+254710546911");
  const [whatsappEnabled, setWhatsappEnabled] = useState(false);
  const [alertSettings, setAlertSettings] = useState({
    lowStock: true,
    tasks: true,
    sales: true,
    profit: false
  });
  
  // Handle phone number verify
  const handleVerifyPhone = () => {
    // In a real app, this would send a verification code via WhatsApp
    if (phoneNumber.length < 10) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid phone number",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Verification Code Sent",
      description: "Check your WhatsApp for the verification code",
    });
  };
  
  // Handle saving settings
  const handleSaveSettings = () => {
    setWhatsappEnabled(true);
    toast({
      title: "Settings Saved",
      description: "Your WhatsApp alert preferences have been updated",
    });
  };
  
  // Handle sending test alert
  const handleSendTest = () => {
    toast({
      title: "Test Alert Sent",
      description: "A test alert has been sent to your WhatsApp",
    });
  };
  
  // Sample alerts data
  const sampleAlerts = [
    {
      id: 1,
      type: "low_stock",
      message: "Low Stock Alert: Oak Saplings (10 remaining)",
      date: "2025-04-15T10:30:00Z",
      status: "sent"
    },
    {
      id: 2,
      type: "task",
      message: "Task Due Tomorrow: Watering Schedule for Pine Seedlings",
      date: "2025-04-14T14:45:00Z",
      status: "sent"
    },
    {
      id: 3,
      type: "sale",
      message: "New Sale: 25 Oak Saplings sold to Green Gardens Ltd",
      date: "2025-04-12T09:15:00Z",
      status: "sent"
    }
  ];
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">WhatsApp Alerts</h1>
        <Button 
          variant="outline" 
          className="flex items-center gap-2"
          onClick={handleSendTest}
          disabled={!whatsappEnabled}
        >
          <MessageCircle className="h-4 w-4" />
          <span>Send Test Alert</span>
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Setup Card */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" /> 
              Setup WhatsApp Alerts
            </CardTitle>
            <CardDescription>
              Connect your WhatsApp to receive instant notifications about important events
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between space-x-2">
              <Label htmlFor="whatsapp-enabled">Enable WhatsApp Alerts</Label>
              <Switch 
                id="whatsapp-enabled" 
                checked={whatsappEnabled} 
                onCheckedChange={setWhatsappEnabled} 
              />
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="phone-number">WhatsApp Business Number</Label>
              <div className="flex space-x-2">
                <Input 
                  id="phone-number" 
                  placeholder="+254710546911"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  disabled
                />
                <Button 
                  variant="secondary" 
                  onClick={handleVerifyPhone}
                  disabled={phoneNumber.length < 10}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Verify
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Enter your WhatsApp phone number with country code
              </p>
            </div>
            
            <div className="pt-4 border-t">
              <h3 className="text-sm font-medium mb-3">Alert Types</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between space-x-2">
                  <div>
                    <Label htmlFor="alert-low-stock" className="text-sm">Low Stock Alerts</Label>
                    <p className="text-xs text-muted-foreground">Get notified when inventory is running low</p>
                  </div>
                  <Switch 
                    id="alert-low-stock" 
                    checked={alertSettings.lowStock} 
                    onCheckedChange={(checked) => setAlertSettings({...alertSettings, lowStock: checked})} 
                  />
                </div>
                
                <div className="flex items-center justify-between space-x-2">
                  <div>
                    <Label htmlFor="alert-tasks" className="text-sm">Task Reminders</Label>
                    <p className="text-xs text-muted-foreground">Get notified about upcoming tasks</p>
                  </div>
                  <Switch 
                    id="alert-tasks" 
                    checked={alertSettings.tasks} 
                    onCheckedChange={(checked) => setAlertSettings({...alertSettings, tasks: checked})} 
                  />
                </div>
                
                <div className="flex items-center justify-between space-x-2">
                  <div>
                    <Label htmlFor="alert-sales" className="text-sm">Sales Alerts</Label>
                    <p className="text-xs text-muted-foreground">Get notified when a sale is recorded</p>
                  </div>
                  <Switch 
                    id="alert-sales" 
                    checked={alertSettings.sales} 
                    onCheckedChange={(checked) => setAlertSettings({...alertSettings, sales: checked})} 
                  />
                </div>
                
                <div className="flex items-center justify-between space-x-2">
                  <div>
                    <Label htmlFor="alert-profit" className="text-sm">Profit Reports</Label>
                    <p className="text-xs text-muted-foreground">Receive weekly profit summaries</p>
                  </div>
                  <Switch 
                    id="alert-profit" 
                    checked={alertSettings.profit} 
                    onCheckedChange={(checked) => setAlertSettings({...alertSettings, profit: checked})} 
                  />
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t pt-4 flex justify-end">
            <Button onClick={handleSaveSettings}>Save Settings</Button>
          </CardFooter>
        </Card>
        
        {/* Custom Alert Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" /> 
              Send Custom Alert
            </CardTitle>
            <CardDescription>
              Send a manual notification to connected WhatsApp
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <Label htmlFor="alert-message">Message</Label>
              <Textarea 
                id="alert-message" 
                placeholder="Enter your custom alert message..."
                rows={4}
              />
            </div>
            
            <div className="flex justify-end">
              <Button disabled={!whatsappEnabled}>
                <MessageCircle className="h-4 w-4 mr-2" />
                Send Now
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Alert History */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-lg">Alert History</CardTitle>
          <CardDescription>
            Recent alerts sent to your WhatsApp
          </CardDescription>
        </CardHeader>
        <CardContent>
          {sampleAlerts.length === 0 ? (
            <div className="py-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                <Bell className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-gray-500">No alerts sent yet</p>
              <p className="text-sm text-gray-400">Configure and enable WhatsApp alerts to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sampleAlerts.map((alert) => (
                <div key={alert.id} className="flex items-start p-3 border rounded-lg">
                  <div className="flex-shrink-0 mr-3">
                    {alert.type === "low_stock" && (
                      <div className="h-8 w-8 bg-yellow-100 rounded-full flex items-center justify-center">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      </div>
                    )}
                    {alert.type === "task" && (
                      <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <Clock className="h-4 w-4 text-blue-600" />
                      </div>
                    )}
                    {alert.type === "sale" && (
                      <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                        <Check className="h-4 w-4 text-green-600" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{alert.message}</p>
                    <div className="flex justify-between mt-1">
                      <p className="text-xs text-muted-foreground">
                        {new Date(alert.date).toLocaleString()}
                      </p>
                      <p className="text-xs font-medium text-green-600">
                        {alert.status === "sent" ? "Sent" : "Failed"}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default WhatsAppAlertsPage;
