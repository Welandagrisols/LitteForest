
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useReports } from "@/hooks/useReports";
import { Skeleton } from "@/components/ui/skeleton";
import { exportToCSV } from "@/utils/csvExport";

interface CostBreakdown {
  speciesId: number;
  name: string;
  inputCost: number;
  laborCost: number;
  totalCost: number;
  numSeedlings: number;
  costPerSeedling: number;
  averagePrice: number;
  profitPerSeedling: number;
}

const CostPerSeedling = () => {
  const { speciesData, tasksData, salesData, isLoadingOverview } = useReports();

  const getCostBreakdown = (): CostBreakdown[] => {
    if (!speciesData || !tasksData || !salesData) return [];

    return speciesData.map(species => {
      // Get all tasks for this species
      const speciesTasks = tasksData.filter(t => t.speciesId === species.id);
      
      // Calculate input costs
      const inputCost = speciesTasks.reduce((sum, task) => sum + Number(task.inputsCost), 0);
      
      // Calculate labor costs
      const laborCost = speciesTasks.reduce((sum, task) => {
        const workers = Number(task.numWorkers) || 1;
        const rate = Number(task.hourlyRate) || 10;
        const hours = Number(task.laborHours) || 0;
        return sum + (workers * rate * hours);
      }, 0);

      // Calculate average selling price
      const speciesSales = salesData.filter(s => s.speciesId === species.id);
      const totalRevenue = speciesSales.reduce((sum, sale) => sum + Number(sale.totalRevenue), 0);
      const totalSold = speciesSales.reduce((sum, sale) => sum + sale.quantity, 0);
      const averagePrice = totalSold > 0 ? totalRevenue / totalSold : 0;

      const totalCost = inputCost + laborCost;
      const costPerSeedling = species.quantity > 0 ? totalCost / species.quantity : 0;
      
      return {
        speciesId: species.id,
        name: species.localName,
        inputCost,
        laborCost,
        totalCost,
        numSeedlings: species.quantity,
        costPerSeedling,
        averagePrice,
        profitPerSeedling: averagePrice - costPerSeedling
      };
    });
  };

  const handleExport = () => {
    const data = getCostBreakdown().map(item => ({
      'Species': item.name,
      'Number of Seedlings': item.numSeedlings,
      'Total Input Cost': `KSh ${item.inputCost.toFixed(2)}`,
      'Total Labor Cost': `KSh ${item.laborCost.toFixed(2)}`,
      'Total Cost': `KSh ${item.totalCost.toFixed(2)}`,
      'Cost per Seedling': `KSh ${item.costPerSeedling.toFixed(2)}`,
      'Average Selling Price': `KSh ${item.averagePrice.toFixed(2)}`,
      'Profit per Seedling': `KSh ${item.profitPerSeedling.toFixed(2)}`
    }));

    exportToCSV(data, 'cost-per-seedling-report.csv');
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold">Cost per Seedling</CardTitle>
        <Button variant="outline" size="icon" onClick={handleExport}>
          <Download className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {isLoadingOverview ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {getCostBreakdown().map((item) => (
              <div key={item.speciesId} className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">{item.name}</span>
                  <span className="text-green-600">
                    KSh {item.profitPerSeedling.toFixed(2)} profit/seedling
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-sm text-muted-foreground">
                  <div>
                    <div>Cost/Seedling</div>
                    <div className="font-medium text-foreground">
                      KSh {item.costPerSeedling.toFixed(2)}
                    </div>
                  </div>
                  <div>
                    <div>Avg. Price</div>
                    <div className="font-medium text-foreground">
                      KSh {item.averagePrice.toFixed(2)}
                    </div>
                  </div>
                  <div>
                    <div>Quantity</div>
                    <div className="font-medium text-foreground">
                      {item.numSeedlings}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CostPerSeedling;
