import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sprout } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface ProfitabilityItem {
  speciesId: number;
  name: string;
  scientificName: string;
  quantitySold: number;
  revenue: number;
  profitPercentage: number;
}

interface ProfitabilitySectionProps {
  profitabilityData: ProfitabilityItem[];
  topSellingProduct?: ProfitabilityItem | null;
  isLoading: boolean;
}

const ProfitabilitySection: React.FC<ProfitabilitySectionProps> = ({ 
  profitabilityData, 
  topSellingProduct,
  isLoading 
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Product Profitability</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          {isLoading ? (
            // Show skeletons when loading
            Array(4).fill(0).map((_, i) => (
              <div key={i}>
                <div className="flex justify-between mb-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-8" />
                </div>
                <Skeleton className="h-2 w-full" />
              </div>
            ))
          ) : profitabilityData.length === 0 ? (
            <div className="py-4 text-center text-gray-500">
              No profitability data available yet
            </div>
          ) : (
            // Display actual profitability data
            profitabilityData.slice(0, 4).map((item) => (
              <div key={item.speciesId}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm">{item.name}</span>
                  <span className="text-sm font-medium">{item.profitPercentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full" 
                    style={{ width: `${item.profitPercentage}%` }}
                  ></div>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-200">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Top Selling Product</h3>
          {isLoading ? (
            <div className="flex items-center gap-3">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div>
                <Skeleton className="h-5 w-24 mb-1" />
                <Skeleton className="h-3 w-32 mb-1" />
                <Skeleton className="h-4 w-20" />
              </div>
            </div>
          ) : !topSellingProduct ? (
            <div className="text-center text-gray-500 py-2">
              No sales data available
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-green-100 rounded-full">
                <Sprout className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-medium">{topSellingProduct.name}</p>
                <p className="text-xs text-gray-500">{topSellingProduct.quantitySold} units sold this month</p>
                <p className="text-sm font-medium text-green-600">KSh {topSellingProduct.revenue} revenue</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfitabilitySection;
