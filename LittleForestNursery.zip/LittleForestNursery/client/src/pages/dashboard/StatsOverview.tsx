import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Sprout, ListTodo, ShoppingCart, DollarSign, TrendingUp, TrendingDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface StatsOverviewProps {
  data?: {
    totalInventory: number;
    openTasks: number;
    monthlySales: number;
    netProfit: number;
  };
  isLoading: boolean;
}

const StatsOverview: React.FC<StatsOverviewProps> = ({ data, isLoading }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Total Inventory */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-sm font-medium text-gray-500">Total Inventory</h3>
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-green-100">
              <Sprout className="h-4 w-4 text-primary" />
            </div>
          </div>
          
          {isLoading ? (
            <Skeleton className="h-8 w-20" />
          ) : (
            <p className="text-2xl font-semibold">{data?.totalInventory || 0}</p>
          )}
          
          <div className="flex items-center text-xs text-primary mt-1">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>+12% from last month</span>
          </div>
        </CardContent>
      </Card>
      
      {/* Open Tasks */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-sm font-medium text-gray-500">Open Tasks</h3>
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-purple-100">
              <ListTodo className="h-4 w-4 text-purple-500" />
            </div>
          </div>
          
          {isLoading ? (
            <Skeleton className="h-8 w-20" />
          ) : (
            <p className="text-2xl font-semibold">{data?.openTasks || 0}</p>
          )}
          
          <div className="flex items-center text-xs text-primary mt-1">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>+3% completion rate</span>
          </div>
        </CardContent>
      </Card>
      
      {/* Monthly Sales */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-sm font-medium text-gray-500">Monthly Sales</h3>
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-100">
              <ShoppingCart className="h-4 w-4 text-accent" />
            </div>
          </div>
          
          {isLoading ? (
            <Skeleton className="h-8 w-20" />
          ) : (
            <p className="text-2xl font-semibold">KSh {data?.monthlySales?.toFixed(2) || "0.00"}</p>
          )}
          
          <div className="flex items-center text-xs text-primary mt-1">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>+18% from last month</span>
          </div>
        </CardContent>
      </Card>
      
      {/* Net Profit */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-sm font-medium text-gray-500">Net Profit</h3>
            <div className="w-8 h-8 flex items-center justify-center rounded-full bg-green-100">
              <DollarSign className="h-4 w-4 text-green-500" />
            </div>
          </div>
          
          {isLoading ? (
            <Skeleton className="h-8 w-20" />
          ) : (
            <p className="text-2xl font-semibold">KSh {data?.netProfit?.toFixed(2) || "0.00"}</p>
          )}
          
          <div className="flex items-center text-xs text-primary mt-1">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>+7% from last month</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StatsOverview;
