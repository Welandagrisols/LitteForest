import React from "react";
import { Link } from "wouter";
import { Plus, ListTodo, ShoppingCart, Droplet, AlertTriangle, Activity } from "lucide-react";

const QuickActions: React.FC = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      <Link href="/species?action=add" className="flex flex-col items-center justify-center h-24 bg-primary text-primary-foreground rounded-lg shadow-sm hover:shadow transition-shadow">
        <Plus className="h-6 w-6 mb-1" />
        <span className="text-sm">Add Inventory</span>
      </Link>
      
      <Link href="/tasks?action=add" className="flex flex-col items-center justify-center h-24 bg-secondary text-secondary-foreground rounded-lg shadow-sm hover:shadow transition-shadow">
        <ListTodo className="h-6 w-6 mb-1" />
        <span className="text-sm">Add Task</span>
      </Link>
      
      <Link href="/sales?action=add" className="flex flex-col items-center justify-center h-24 bg-blue-500 text-white rounded-lg shadow-sm hover:shadow transition-shadow">
        <ShoppingCart className="h-6 w-6 mb-1" />
        <span className="text-sm">Record Sale</span>
      </Link>
      
      <Link href="/tasks?type=watering" className="flex flex-col items-center justify-center h-24 bg-cyan-500 text-white rounded-lg shadow-sm hover:shadow transition-shadow">
        <Droplet className="h-6 w-6 mb-1" />
        <span className="text-sm">Watering Schedule</span>
      </Link>
      
      <Link href="/reports?type=alerts" className="flex flex-col items-center justify-center h-24 bg-amber-500 text-white rounded-lg shadow-sm hover:shadow transition-shadow">
        <AlertTriangle className="h-6 w-6 mb-1" />
        <span className="text-sm">Stock Alert</span>
      </Link>
      
      <Link href="/species?action=health" className="flex flex-col items-center justify-center h-24 bg-emerald-500 text-white rounded-lg shadow-sm hover:shadow transition-shadow">
        <Activity className="h-6 w-6 mb-1" />
        <span className="text-sm">Health Check</span>
      </Link>
    </div>
  );
};

export default QuickActions;
