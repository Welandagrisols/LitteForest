import React from "react";
import QuickActions from "./QuickActions";
import StatsOverview from "./StatsOverview";
import RevenueChart from "./RevenueChart";
import ProfitabilitySection from "./ProfitabilitySection";
import CostPerSeedling from "./CostPerSeedling";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sprout, ShoppingCart } from "lucide-react";
import { Link } from "wouter";

const Dashboard: React.FC = () => {
  const { data: overviewData, isLoading } = useQuery({
    queryKey: ["/api/reports/overview"],
  });

  return (
    <>
      {/* Quick Actions Section */}
      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
        <QuickActions />
      </section>

      {/* Nursery Overview Section */}
      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Nursery Overview</h2>
        <StatsOverview data={overviewData} isLoading={isLoading} />
      </section>

      {/* Revenue and Profitability Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Monthly Revenue Chart */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-semibold">Monthly Revenue</CardTitle>
              <div className="flex gap-2">
                <Button variant="default" className="h-8 px-3 bg-secondary hover:bg-secondary/90">This Year</Button>
                <Button variant="outline" className="h-8 px-3">Last Year</Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-64">
                <RevenueChart />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Product Profitability */}
        <div className="col-span-4">
          <div className="space-y-4">
            <ProfitabilitySection 
              profitabilityData={overviewData?.profitability || []} 
              topSellingProduct={overviewData?.topSellingProduct}
              isLoading={isLoading}
            />
            <CostPerSeedling />
          </div>
        </div>
      </div>

      {/* Recent Activity Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Recent Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Recent Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            {/* When there are no tasks */}
            <div className="py-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                <ListTodo className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-gray-500">No recent tasks</p>
              <p className="text-sm text-gray-400">Add tasks to track your nursery operations</p>
            </div>

            <Button asChild className="w-full mt-4 bg-secondary hover:bg-secondary/90">
              <Link href="/tasks">View All Tasks</Link>
            </Button>
          </CardContent>
        </Card>

        {/* Recent Sales */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Recent Sales</CardTitle>
          </CardHeader>
          <CardContent>
            {/* When there are no sales */}
            <div className="py-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto flex items-center justify-center mb-3">
                <ShoppingCart className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-gray-500">No recent sales</p>
              <p className="text-sm text-gray-400">Record sales to track your revenue</p>
            </div>

            <Button asChild className="w-full mt-4 bg-secondary hover:bg-secondary/90">
              <Link href="/sales">View All Sales</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Current Inventory Preview */}
      <section className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Current Inventory</h2>
          <Link href="/species" className="text-accent text-sm hover:underline">View All</Link>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Species</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Scientific Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Establishment Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center">Loading inventory...</td>
                  </tr>
                ) : overviewData?.speciesData?.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-4 text-center">No species in inventory</td>
                  </tr>
                ) : (
                  <>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                            <Sprout className="h-4 w-4 text-primary" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">Oak Saplings</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">Quercus robur</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">132</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">Mar 12, 2025</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button className="text-accent hover:text-accent/80">
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-gray-700">
                            <InfoIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                            <Sprout className="h-4 w-4 text-primary" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">Pine Seedlings</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">Pinus sylvestris</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">85</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">Apr 3, 2025</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button className="text-accent hover:text-accent/80">
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-gray-700">
                            <InfoIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                            <Sprout className="h-4 w-4 text-primary" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">Maple Trees</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">Acer saccharum</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">43</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">Feb 28, 2025</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button className="text-accent hover:text-accent/80">
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-gray-700">
                            <InfoIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </section>
    </>
  );
};

// Icons
const ListTodo: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
    className={className}
  >
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <line x1="3" y1="6" x2="3.01" y2="6" />
    <line x1="3" y1="12" x2="3.01" y2="12" />
    <line x1="3" y1="18" x2="3.01" y2="18" />
  </svg>
);

const PencilIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
    className={className}
  >
    <path d="M12 20h9"/>
    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
  </svg>
);

const InfoIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
    className={className}
  >
    <circle cx="12" cy="12" r="10"/>
    <line x1="12" y1="16" x2="12" y2="12"/>
    <line x1="12" y1="8" x2="12.01" y2="8"/>
  </svg>
);

export default Dashboard;