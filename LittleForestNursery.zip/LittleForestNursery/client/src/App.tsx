import { Route, Switch } from "wouter";
import AppLayout from "./components/layout/AppLayout";
import Dashboard from "./pages/dashboard/Dashboard";
import SpeciesPage from "./pages/species/SpeciesPage";
import InputsPage from "./pages/inputs/InputsPage";
import TasksPage from "./pages/tasks/TasksPage";
import SalesPage from "./pages/sales/SalesPage";
import ReportsPage from "./pages/reports/ReportsPage";
import WhatsAppAlertsPage from "./pages/whatsapp/WhatsAppAlertsPage";
import SettingsPage from "./pages/settings/SettingsPage";
import NotFound from "./pages/not-found";

function App() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/species" component={SpeciesPage} />
        <Route path="/inputs" component={InputsPage} />
        <Route path="/tasks" component={TasksPage} />
        <Route path="/sales" component={SalesPage} />
        <Route path="/reports" component={ReportsPage} />
        <Route path="/whatsapp-alerts" component={WhatsAppAlertsPage} />
        <Route path="/settings" component={SettingsPage} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

export default App;
