import { pgTable, text, serial, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Species/Plants table
export const species = pgTable("species", {
  id: serial("id").primaryKey(),
  localName: text("local_name").notNull(),
  scientificName: text("scientific_name"),
  quantity: integer("quantity").notNull().default(0),
  establishmentDate: timestamp("establishment_date").notNull(),
  notes: text("notes"),
});

// Create base schema with DrizzleORM
const baseInsertSpeciesSchema = createInsertSchema(species).omit({ id: true });

// Extend with custom transformations for dates
export const insertSpeciesSchema = baseInsertSpeciesSchema.transform((data) => {
  return {
    ...data,
    // Convert date string to Date object if it's a string
    establishmentDate: typeof data.establishmentDate === 'string' 
      ? new Date(data.establishmentDate) 
      : data.establishmentDate
  };
});
export type InsertSpecies = z.infer<typeof insertSpeciesSchema>;
export type Species = typeof species.$inferSelect;

// Input categories enum
export const inputCategoryEnum = z.enum([
  "Seed",
  "Fertilizer",
  "Tool",
  "Soil",
  "Chemical",
  "Container",
  "Other"
]);
export type InputCategory = z.infer<typeof inputCategoryEnum>;

// Inputs (non-living inventory) table
export const inputs = pgTable("inputs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull().default("0"),
  unit: text("unit").notNull(),
  unitCost: decimal("unit_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  totalCost: decimal("total_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  dateReceived: timestamp("date_received").notNull(),
  notes: text("notes"),
});

// Create base schema with DrizzleORM
const baseInsertInputSchema = createInsertSchema(inputs).omit({ id: true });

// Extend with custom transformations for dates
export const insertInputSchema = baseInsertInputSchema.transform((data) => {
  return {
    ...data,
    // Convert date string to Date object if it's a string
    dateReceived: typeof data.dateReceived === 'string' 
      ? new Date(data.dateReceived) 
      : data.dateReceived
  };
});
export type InsertInput = z.infer<typeof insertInputSchema>;
export type Input = typeof inputs.$inferSelect;

// Tasks table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  speciesId: integer("species_id").default(null), // Link to specific species
  speciesInvolved: text("species_involved").default(''),
  date: timestamp("date").notNull(),
  numWorkers: integer("num_workers").notNull().default(1),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }).notNull().default("10"),
  laborHours: decimal("labor_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  laborCost: decimal("labor_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  inputsCost: decimal("inputs_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  totalCost: decimal("total_cost", { precision: 10, scale: 2 }).notNull().default("0"),
  notes: text("notes").default(''),
  status: text("status").notNull().default("Pending"),
  dueDate: timestamp("due_date").default(null),
  assignedTo: text("assigned_to").default(''),
});

// Create base schema with DrizzleORM
const baseInsertTaskSchema = createInsertSchema(tasks).omit({ id: true });

// Extend with custom transformations for dates
export const insertTaskSchema = baseInsertTaskSchema.transform((data) => {
  return {
    ...data,
    // Convert date string to Date object if it's a string
    date: typeof data.date === 'string' ? new Date(data.date) : data.date,
    // Handle dueDate (which can be null)
    dueDate: data.dueDate ? 
      (typeof data.dueDate === 'string' ? new Date(data.dueDate) : data.dueDate) 
      : null
  };
});
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// Task Inputs join table
export const taskInputs = pgTable("task_inputs", {
  id: serial("id").primaryKey(),
  taskId: integer("task_id").notNull(),
  inputId: integer("input_id").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  cost: decimal("cost", { precision: 10, scale: 2 }).notNull().default("0"),
});

export const insertTaskInputSchema = createInsertSchema(taskInputs).omit({ id: true });
export type InsertTaskInput = z.infer<typeof insertTaskInputSchema>;
export type TaskInput = typeof taskInputs.$inferSelect;

// Sales table
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  speciesId: integer("species_id").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  totalRevenue: decimal("total_revenue", { precision: 10, scale: 2 }).notNull(),
  buyer: text("buyer"),
  date: timestamp("date").notNull(),
  notes: text("notes"),
});

// Create base schema with DrizzleORM
const baseInsertSaleSchema = createInsertSchema(sales).omit({ id: true });

// Extend with custom transformations for dates
export const insertSaleSchema = baseInsertSaleSchema.transform((data) => {
  return {
    ...data,
    // Convert date string to Date object if it's a string
    date: typeof data.date === 'string' ? new Date(data.date) : data.date
  };
});
export type InsertSale = z.infer<typeof insertSaleSchema>;
export type Sale = typeof sales.$inferSelect;

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("user"),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
